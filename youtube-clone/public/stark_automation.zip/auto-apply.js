import Flow from './execute.js';
import { getHTML, fetchRequest, getUserData } from './utils.js';
class AutoApply {
  constructor(portal, token, tab) {
    this.portal = portal;
    this.token = token;
    this.tab = tab;
  }

  async exec_apply_job(job, portalFlow) {
    const jobDetails = await getHTML(this.tab.id, job.url);
    const jobDescription = await fetchRequest('/portals/job-details', {
      job_url: jobDetails.html,
      portal: this.portal,
      access_token: this.token,
    });

    const userData = await getUserData(this.token);
    const resumeData = JSON.parse(userData?.resumeData);
    const resumeText = resumeData.find(resume => resume.uuid === job.profile_uuid)?.text || '';

    const aiScore = await fetchRequest('/ai/relevance', {
      job_description_text: jobDescription.description,
      resume_text: resumeText,
      access_token: this.token,
    });
    job.computedScore = aiScore.relevance_score || '0'
    if (parseInt(job.matchScore) > parseFloat(job.computedScore)) {
      console.log('Score is low. Skipped');
      return { status: 'skipped', reason: `Low AI matching score (${job.computedScore})` }
    }

    const flow = new Flow(this.tab.id, portalFlow, job, this.portal);
    const status = await flow.execute();
    console.log("status", status);
    console.log('job completed', job);

    return {
      status: (status?.reason?.toLowerCase()?.includes('already') ? 'skipped' : status?.reason?.length && !status?.is_applied? 'failed' : 'applied'),
      reason: (status?.reason?.toLowerCase()?.includes('already') ? 'Already applied' : status?.reason || null)
    }
  }
}

export { AutoApply };
