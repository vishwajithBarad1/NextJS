import { getJobScheduler } from './scheduler.js';
import { contentScriptListener } from './listeners/contentScript.js';
import { starkAIListener } from './listeners/starkAI.js';
import { popupListener } from './listeners/popup.js';
import { getStarkAccessToken, getUserData } from './utils.js';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Received message:', request);

  if (request.action === 'get_portal_user_info') {
    chrome.storage.local.get(['portals_info'], result => {
      getStarkAccessToken(accessTokenResponse => {
        sendResponse({
          portals_info: result.portals_info,
          access_token: accessTokenResponse.accessToken,
        });
      });
      return true;
    });
  } else if (request.action === 'get_user_data') {
    getUserData(request.accessToken, request.forceRefresh)
      .then(userData => sendResponse({ userData }))
      .catch(error => sendResponse({ error: error.message }));
    return true;
  } else if (request.action === 'get_pending_jobs') {
    const { portal, searchUrl } = request.data
    // Set storage key based on portal name
    const storageKey = `stark-jobs-${portal}-scheduled-jobs`

    // Get data from storage key and send response based on given search url
    chrome.storage.local.get(storageKey, items => {
        const jobs = items?.[storageKey] || [];
        const scheduledJobs = jobs?.filter(job => job?.searchUrl === searchUrl);
        sendResponse({ scheduledJobs });
    });
    return true
  } else if (request.action === 'remove-job-search') {
    const { portal, jobSearchUrl, profile } = request.data;
    getJobScheduler()?.removeJobSearch(portal, jobSearchUrl, profile);
    sendResponse({ status: 'success' })
    return true;
  } else if (request.src === 'contentScript') {
    return contentScriptListener(request, sender, sendResponse);
  } else if (request.src === 'starkAI') {
    return starkAIListener(request, sender, sendResponse);
  } else if (request.src === 'popup') {
    return popupListener(request, sender, sendResponse);
  }

  return true;
});
