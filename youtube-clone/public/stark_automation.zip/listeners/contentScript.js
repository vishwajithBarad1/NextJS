import { fetchJobScore } from '../utils.js';

export function contentScriptListener(request, sender, sendResponse) {
  if (request.action === 'fetch_job_score') {
    fetchJobScore(request)
      .then(data => sendResponse(data))
      .catch(error => sendResponse({ error: error.message }));
  }
  return true;
}
