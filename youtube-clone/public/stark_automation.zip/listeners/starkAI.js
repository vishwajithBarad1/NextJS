import { getJobScheduler } from "../scheduler.js";
import { getHTML, fetchJobScore } from "../utils.js";

export function starkAIListener(request, sender, sendResponse) {
    if (request.action === 'get_version') {
        sendResponse({ version: chrome.runtime.getManifest().version });
    } else if (request.action === 'get_pending_jobs') {
        const { portal, searchUrl } = request.data
        // Set storage key based on portal name
        const storageKey = `stark-jobs-${portal}-scheduled-jobs`

        // Get data from storage key and send response based on given search url
        chrome.storage.local.get(storageKey, items => {
            const jobs = items?.[storageKey] || [];
            const scheduledJobs = jobs?.filter(job => job?.searchUrl === searchUrl);
            sendResponse({ scheduledJobs });
        });
        return true
    }
    else if (request.action === 'job_details') {
        getHTML('', request.data.url).then(response => {
            fetchJobScore({
                jobDescription: response.html,
                resume_text: request.data.resume_text,
                portalName: request.data.portal,
                accessToken: request.data.accessToken, // Include the access token in the request body
            }).then(jobResponse => sendResponse({ message: jobResponse })).catch(error => sendResponse({ message: error }))
        }).catch(error => sendResponse({ message: error }))
    } else if (request.action === 'add-job-search') {
        const { portal, jobSearchUrl, profile } = request.data;
        console.log("New job search added - ", portal, jobSearchUrl, profile)
        getJobScheduler().addJobSearch(portal, jobSearchUrl, profile);
        sendResponse({ status: 'success' })
        return true;
    } else if (request.action === "profile-deletion") {
        const profileId = request.data.profileId;
        getJobScheduler().deleteJobsForProfile(profileId);
        sendResponse({ status: 'success' });
        return true;
    }
    else if (request.action === "update-active-tab") {
        chrome.tabs.create({ url: `${request.data.url}/auto-apply`, active: true })
        sendResponse({ status: 'success' })
    }

    return true; // Keep the message channel open for sendResponse
}
