export function popupListener(request, sender, sendResponse) {
  return true;
}
