import { startJobScheduler } from './scheduler.js';
import { downloadPortalsInfo } from './utils.js';
import './listener.js' // Import listener.js to ensure it's executed

chrome.runtime.onInstalled.addListener(() => {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/stark-256.png',
    title: 'Stark.ai',
    message: 'Thanks for installing Stark.ai! Pin the extension to your browser to automatically apply to jobs effortlessly.',
  });

  downloadPortalsInfo();
  startJobScheduler();
});

chrome.runtime.onStartup.addListener(() => {
  downloadPortalsInfo();
  startJobScheduler();
});

