import { PORTALS_URL, getStarkAccessToken } from './utils.js';

class Flow {
    constructor(tabId, flows, job, portal) {
        this.tabId = tabId;
        this.flows = flows;
        this.job = job;
        this.portal = portal;
        this.status = null;
        this.reason = null;
        this.token = null;
        this.questionCounts = {};
    }

    // Get step details by stepId
    getStep(stepId) {
        return this.flows.find(item => item.step === stepId);
    }

    // Execute the current step
    async executeStep(step, result) {
        try {
            switch (step.command) {
                case 'check-xpath':
                    // Check if XPath exists
                    result = await this.checkXpath(step);
                    break;
                case 'click':
                    // Click button
                    result = await this.clickXpath(step);
                    break;
                case 'fill-form':
                    // Fill the form
                    result = await this.formFill(step);
                    break;
                case 'wait':
                    await this.waitFor(step);
                    break;
                case 'debugger':
                    // Send command to debugger
                    await this.sendDebuggerCommand(step);
                    break;
                case 'reload':
                    // Tab reload
                    result = await this.reload(step);
                    break;
            }
            return result;
        } catch (error) {
            console.error('Error executing step:', error);
            throw error;
        }
    }

    // Handler function to send a command to the debugger
    async sendDebuggerCommand(action) {
        await chrome.debugger.sendCommand({ tabId: this.tabId }, action?.event_name, { ...action?.data });
    }

    // Handler function to reload tab with provided/job url
    async reload(action) {
        // Set the URL if provided in flow step, default as original job url
        const url = action?.url || this.job.url
        if (!url) return false

        // Return a new Promise after tab updated with url and loading completed
        return new Promise(resolve => {
            chrome.tabs.update(this.tabId, { url: url, active: false }, () => {

                // Handler function to resolve promise after completion of tab loading
                const listener = async (updatedTabId, changeInfo) => {
                    if (updatedTabId === this.tabId && changeInfo.status === 'complete') {
                        chrome.tabs.onUpdated.removeListener(listener); // Remove the listener
                        resolve(true)
                    }
                };
                chrome.tabs.onUpdated.addListener(listener);
            })
        })
    }

    // Wait for an element specified by XPath to load within a given time frame
    async waitFor(action) {
        return new Promise((resolve, reject) => {
            const interval = 500; // Check for the element every 100ms
            const timeout = action?.time || 5000;
            const maxAttempts = timeout / interval;
            let attempts = 0;

            // Function to check for the presence of the element
            const checkForElement = async (action) => {
                const element = await this.checkXpath(action);
                if (element && element?.trim()?.length) {
                    // If the element is found, resolve the promise with the element
                    resolve(element);
                } else if (attempts >= maxAttempts) {
                    // If the maximum attempts limit is reached without finding the element, reject the promise
                    resolve(null);
                } else {
                    // If the element is not found yet and attempts are within the limit, increment attempts and check again after a short delay
                    attempts += 1;
                    setTimeout(() => checkForElement(action), interval);
                }
            };

            // Initial call to start checking for the element
            checkForElement(action);
        });
    }

    // Helper function to check XPath
    async checkXpath(action, returnType = 'attribute') {
        const response = await chrome.scripting.executeScript({
            args: [{ action, returnType }],
            target: { tabId: this.tabId },
            function: params => {
                const element = document.evaluate(params.action.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                if (!element) return false;

                // Return the element's location if returnType is set to "location"
                if (params.returnType === "location") return { x: element.getBoundingClientRect().x, y: element.getBoundingClientRect().y }

                // Otherwise, return the specified attribute value of the element (default is innerText)
                const attribute = params.action?.attribute || 'innerText';
                return element?.[attribute];
            },
        });
        return response?.[0]?.result;
    }

    // Helper function to click xpath
    async clickXpath(action) {
        const clickResponse = await chrome.scripting.executeScript({
            args: [action],
            target: { tabId: this.tabId },
            function: action => {
                const apply = document.evaluate(action.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                if (!apply) return false;

                if (action?.targetXpath) {
                    const targetElement = document.evaluate(action.targetXpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                    targetElement.target = '_self'
                }

                apply.click();
                return 'success';
            },
        });
        return clickResponse?.[0]?.result;
    }

    // Helper function to form filling

    async formFill(action) {
        if (this.portal == "naukri") {
            return await this.naukriFormFill(action)
        } else {
            return await this.linkedinFormFill(action)
        }
    }

    async naukriFormFill(action) {

        // Define default values
        const Question = {
            question: "",
            answer_type: "",
            options: [],
            instruction: ""
        };

        const question_answer = { question: "", answer_xpath: {} }
        const questions = []
        for (const step of action.data) {
            let questionObj = { ...Question }; // Create a new question object with default values
            if (step.action === 'check-form') {
                const elementData = await this.waitUntilFormLoaded_(step);

                // Check for form content
                if (!elementData || !elementData?.trim()?.length) return false;

            } else if (step.action === 'question') {
                const quest = await this.getQuestion(step)
                if (!quest) return false;
                questionObj.question = quest
                question_answer.question = quest

                for (const answer_step of step.answers_xpaths) {
                    let result;
                    if (answer_step.action === 'check-radio' || answer_step.action === 'check-box') {
                        result = await this.clickRandomButton(answer_step);
                    } else if (answer_step.action === 'dropdown') {
                        result = await handleDropdown(answer_step);
                    } else if (answer_step.action === "check-text") {
                        result = await this.inputText(answer_step);
                    } else if (answer_step.action === "check-text-area") {
                        result = await this.inputTextArea(answer_step);
                    }
                    if (result) {
                        questionObj.answer_type = result.answerType;
                        questionObj.options = result.options;
                        question_answer.answer_xpath = answer_step
                        break; // Exit the loop if a result is obtained
                    }
                }
            }

            if (questionObj.question) {
                questions.push(questionObj);
            }
        }
        console.log("Questions", questions)

        // Filling the answers
        if (questions.length > 0) {
            const formResponse = await getAnswersFromAi(this.job.profile_uuid, questions);
            if(!formResponse || !formResponse?.data?.answered_questions) return false
            
            const skipped_step = action.data[action.data.length - 2]

            const response = await this.prefillAnswers(formResponse.data.answered_questions, question_answer, skipped_step);
            if (response) {

                // If the response is submitted return success or failure based on checkSubmit
                if (action.data && action.data.length > 0 && action.data[action.data.length - 1].action === "save-response") {

                    try {
                        if (await this.checkSubmit(action.data[action.data.length - 1])) {
                            console.log("Submitted the response");
                            return 'success';
                        }
                    } catch (error) {
                        console.error("Error in checkSubmit:", error);
                    }

                    return 'failure';
                }
            } else {
                return false
            }
        }
    }

    // Linkedin form fill
    async linkedinFormFill(step) {
        // Fetch the form questions
        const data = await chrome.scripting.executeScript({
            args: [step, this.job, PORTALS_URL, this.tabId],
            target: { tabId: this.tabId },
            function: extractFormQuestions,
        });

        // Extract form questions from the fetched data and append index
        const formQuestions = data[0].result.map((question, index) => ({ ...question, index }))

        try {
            // Get answers from AI based on the extracted form questions
            const response = await getAnswersFromAi(this.job.profile_uuid, formQuestions);
            const formResponse = response?.data?.answered_questions;

            // Check for form response from ai
            if(!formResponse || !formResponse?.length) return false

            // Prepare the final questions object with answers
            const finalQuestions = formResponse.map(q => ({
                question: q.question,
                answer_type: q.answer_type,
                value: q.answer,
                index: q.index
            }));

            for (const finalQuestion of finalQuestions){
                if (finalQuestion) {
                    // Update the question count
                    const question = finalQuestion.question.trim().toLowerCase();
                    if (!this.questionCounts[question]) {
                        this.questionCounts[question] = 1;
                    } else {
                        this.questionCounts[question] += 1;
                    }
                    // Check if the question has been repeated three times
                    if (this.questionCounts[question] >= 2) {
                        this.reason = "This job takes too long time to apply";
                        return false;
                    }
                }
            }
           
            // Prefill the form with AI responses using a Chrome scripting function
            const res = await chrome.scripting.executeScript({
                args: [step, finalQuestions, formQuestions],
                target: { tabId: this.tabId },
                function: prefillFormWithResponses,
            });

            // Extract the prefill response
            const prefillResponse = res[0].result;
            if (!prefillResponse?.response) this.reason = prefillResponse?.reason;

            return prefillResponse?.response;

        } catch (error) {
            this.reason = `Unable to get answers for form apply due to ${error?.message || error?.error || error?.detail}`;
            return false;
        }
    }

    // Wait to form
    async waitUntilFormLoaded_(step) {
        const data = await chrome.scripting.executeScript({
            args: [step],
            target: { tabId: this.tabId },
            function: step => {
                const index = step?.number != undefined ? step.number : 1;
                const element = document.evaluate(step.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

                if (!element) return false;

                if (!element?.children || !element?.children?.length) return element?.[step?.attribute];

                return element?.children?.length ? element?.children?.[element?.children?.length - index]?.[step?.attribute] : false;
            },
        });
        return data[0].result;
    }

    // Getting question
    async getQuestion(step) {
        const result = await chrome.scripting.executeScript({
            args: [step],
            target: { tabId: this.tabId },

            function: params => {
                const nodes = document.evaluate(params.xpath, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                let element = nodes.iterateNext();
                let lastElement;
                while (element) {
                    lastElement = element;
                    element = nodes.iterateNext();
                }

                return lastElement ? lastElement.textContent.trim() : null;
            }
        });

        return result[0].result;
    }

    // Check and submit
    async checkSubmit(step) {
        try {
            const result = await chrome.scripting.executeScript({
                args: [step],
                target: { tabId: this.tabId },
                func: (params) => {
                    const submit = document.evaluate(params.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                    if (!submit) return false;
                    submit.click();
                    return true;
                }
            });

            return result[0].result;
        } catch (error) {
            console.error("Error during checkSubmit:", error);
            return false;
        }
    }

    // Check the radio button and get the option that having
    async clickRandomButton(step) {
        const result = await chrome.scripting.executeScript({
            args: [step],
            target: { tabId: this.tabId },
            func: params => {
                // Get elements using XPath
                const elements = document.evaluate(params.xpath, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);

                if (!elements) return;

                // Set first element
                let element = elements.iterateNext();
                if (!element) return;

                // Return answer type based on the element type (radio)
                const answerType = element.type;

                const getOptions = (optionsXpath) => {
                    const optionsElements = document.evaluate(optionsXpath, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                    if (!optionsElements) return [];

                    let optionElement = optionsElements.iterateNext();
                    if (!optionElement) return [];
                    let options = [];

                    // Collect all matching elements
                    while (optionElement) {
                        options.push(optionElement.value);
                        optionElement = optionsElements.iterateNext();
                    }

                    return options;
                };

                // Get options if available
                const options = params.options_xpath ? getOptions(params.options_xpath) : [];

                // Returning the result
                return { answerType, options };
            },
        });

        // Ensure result is correctly accessed
        if (result && result.length > 0) {
            return result[0].result;
        } else {
            console.log("No result returned");
            return null;
        }
    }

    async dropdown(step) {
        const result = await chrome.scripting.executeScript({
            args: [step],
            target: { tabId: this.tabId },
            func: params => {
                const selectElement = document.evaluate(params.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

                if (!selectElement || selectElement.tagName !== 'SELECT') return;

                // Use selectElement.type to get the answer type
                const answerType = selectElement.type;

                const getOptions = (optionsXpath) => {
                    const optionsElements = document.evaluate(optionsXpath, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                    if (!optionsElements) return [];

                    let optionElement = optionsElements.iterateNext();
                    if (!optionElement) return [];
                    let options = [];

                    // Collect all matching elements
                    while (optionElement) {
                        options.push(optionElement.value);
                        optionElement = optionsElements.iterateNext();
                    }

                    return options;
                };
                // Get options available in the dropdown using getOptions function
                const options = getOptions(params.options_xpath);

                return { answerType, options };
            },
        });

        return result[0].result

    }

    // Identify the input text field 
    async inputText(step) {
        const result = await chrome.scripting.executeScript({
            args: [step],
            target: { tabId: this.tabId },
            func: params => {
                const inputEle = document.evaluate(params.xpath, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                if (!inputEle) return false;

                // Set first element
                let element = inputEle.iterateNext();
                if (!element) return false;

                // Return answer type based on the element type
                const answerType = element.type;

                const getOptions = (optionsXpath) => {
                    const optionsElements = document.evaluate(optionsXpath, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                    if (!optionsElements) return [];

                    let optionElement = optionsElements.iterateNext();
                    if (!optionElement) return [];
                    let options = [];

                    // Collect all matching elements
                    while (optionElement) {
                        options.push(optionElement.getAttribute('data-scc-val'));
                        optionElement = optionsElements.iterateNext();
                    }

                    return options;
                };

                const options = (params.options_xpath) ? getOptions(params.options_xpath) : [];

                return { answerType, options };
            },
        });

        return result[0].result;
    }

    // For input text area
    async inputTextArea(step) {
        const result = await chrome.scripting.executeScript({
            args: [step],
            target: { tabId: this.tabId },
            func: params => {

                // Get the first element using XPath
                const inputAreaElement = document.evaluate(params.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                const element = inputAreaElement.singleNodeValue;

                if (!element) return false;

                const answerType = params.type;

                const options = []

                return { answerType, options };
            }
        });
        return result[0].result
    }

    async input(step) {
        await chrome.scripting.executeScript({
            args: [step],
            target: { tabId: this.tabId },
            function: params => {
                // Get elements
                const element = document.evaluate(params.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                if (!element) return;
                const response = params?.type && params?.type === 'number' ? '0' : 'N/A';
                const attribute = params?.attribute || 'innerText';
                element[attribute] = response;
                element?.dispatchEvent(new Event(params?.event, { bubbles: true }));
            },
        });
    }

    // Handler function to simulates input using debugger
    async debuggerInput(step) {
        // Determine the response based on the step type
        const response = step?.type && step?.type === "number" ? "0" : "N/A"

        // Mouse click on input tag for focus
        await this.debuggerClick(step)

        // Simulate key presses for each character in the response
        for (let index = 0; index < response?.length; index++) {
            await this.sendDebuggerCommand({ event_name: "Input.dispatchKeyEvent", data: { type: "keyDown", text: response?.[index] } })
        }
    }

    // Handler function to dispatch mouse click event using debugger
    async debuggerClick(step) {
        // Get the location of the element
        const elementLocation = await this.checkXpath(step, 'location')
        if (!elementLocation) return false

        // Define mouse click event data
        const mouseClickEventData = {
            button: "left",
            x: elementLocation.x,
            y: elementLocation.y,
            clickCount: 1,
        }

        // Send command to dispatch mouse click event on the element
        await this.sendDebuggerCommand({ event_name: "Input.dispatchMouseEvent", data: { type: "mousePressed", ...mouseClickEventData } })
        await this.sendDebuggerCommand({ event_name: "Input.dispatchMouseEvent", data: { type: "mouseReleased", ...mouseClickEventData } })
    }

    // Recursive function to execute the flow steps
    async _executeStep(step) {
        try {
            // Execute step
            this.status = await this.executeStep(step, this.status);

            let nextStep = {};

            // Get next step based on the response
            if (this.status) nextStep = this.getStep(step?.success);
            else nextStep = this.getStep(step?.failure);

            // Set reason if exists in the object
            if (step?.reason !== undefined) this.reason = step?.reason;

            let isLastStep = false
            if(step?.is_last_step && this.status && this.status?.length) isLastStep = step?.is_last_step

            // If current command not found, return
            if (!nextStep || !Object.keys(nextStep)?.length) return { is_applied: isLastStep, reason: this.reason };

            // Execute next step
            return this._executeStep(nextStep);
        } catch (error) {
            console.log('Error executing step:', error);
            return { is_applied: false, reason: error?.message || error?.detail || error?.error };
        }
    }

    async prefillAnswers(answered_questions, question_answer, skipped_step) {
        for (const question of answered_questions) {
            // Get xpath for the particular question
            const xpathObject = getXPathForQuestion(question.question, question_answer);

            let result = false;

            // If the answer is not found in the resume, try to skip the question
            if (!question.answer || question.answer.toLowerCase() === "not found in resume") {
                console.log("Question not found in the resume")
                const skipResult = await chrome.scripting.executeScript({
                    args: [skipped_step],
                    target: { tabId: this.tabId },
                    func: (skipped_step) => {
                        const skipElement = document.evaluate(skipped_step.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                        const element = skipElement.singleNodeValue;
                        if (!element) return false;
                        element.click();
                        return true;
                    }
                });

                if (!skipResult[0].result)
                    this.reason = `Answer ${question.answer} for the Question: ${question.question}`;

                result = skipResult[0].result;
            } else {
                const answerResult = await chrome.scripting.executeScript({
                    args: [question, xpathObject],
                    target: { tabId: this.tabId },
                    func: (question, xpathObject) => {
                        if (question.answer_type === 'radio') {
                            // Use options_xpath to find the correct radio button
                            const options = document.evaluate(xpathObject.xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);

                            if (!options) {
                                return false;
                            }

                            for (let i = 0; i < options.snapshotLength; i++) {
                                const option = options.snapshotItem(i);
                                if (option.value === question.answer) {
                                    option.checked = xpathObject.value;
                                    option.dispatchEvent(new Event(xpathObject.event, { bubbles: true }));
                                    return true;
                                }
                            }
                        } else {
                            const inputXpathElement = document.evaluate(xpathObject.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                            const element = inputXpathElement.singleNodeValue;

                            if (!element) {
                                return false;
                            };
                            const attribute = xpathObject.attribute;
                            element[attribute] = question.answer; // Use the answer from the question object
                            element.dispatchEvent(new Event(xpathObject.event, { bubbles: true }));
                        }

                        return true;
                    },
                });
                if (!answerResult[0].result) {
                    console.log("element not found for xpath --->", xpathObject)
                    this.reason = `The form fill element is not found`;
                }
                result = answerResult[0].result;
            }

            if (!result) {
                // Handle failure case
                console.error(`Failed to process question: ${question.question}`);
                return false; // Or handle the failure as needed
            }
        }

        return true; // Return true if all questions were processed successfully
    }

    // Execute the flow
    async execute() {
        await getStarkAccessToken((token) => {
            this.token = token.accessToken;
        })

        // Get start step
        const startStep = this.getStep('start');

        // Create a promise that resolves after the specified timeout
        const timeoutPromise = new Promise((resolve) => {
            setTimeout(() => {
                resolve({ is_applied: false, reason: 'Timed out' });
            }, 3 * 60 * 1000); // 3 minutes in milliseconds
        });

        // Create a promise that resolves when the execution completes
        const executionPromise = this._executeStep(startStep);

        // Wait for either the execution to complete or the timeout to occur
        const result = await Promise.race([executionPromise, timeoutPromise]);

        // If the execution completed within the timeout, return the execution result
        return result;
    }
}

async function getAnswersFromAi(profile_id, questions) {
    const url = `${PORTALS_URL}/ai/form-apply`;
    const payload = {
        profile_id: profile_id,
        questions: questions.map(question => ({
            question: question.question,
            answer_type: question.answer_type,
            options: question.options,
            instruction: question.instruction,
            index: question.index
        }))
    };

    const result = await fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    });

    if (!result.ok) {
        const error = await result.json()
        console.log('Error while getting data to fill form', error)
        this.reason = `Failed to get data to fill form, Error: ${error}`;
        return false
    }
    const jsonResponse = await result.json();

    return jsonResponse
}

function normalizeText(text) {
    return text.replace(/\s+/g, ' ').trim().replace(/[.,?!;:()]/g, '').toLowerCase();
}

function getXPathForQuestion(questionText, question_answer) {

    // Normalize both the input question text and the question_answer.question
    const normalizedQuestionText = normalizeText(questionText);
    const normalizedQuestionAnswer = normalizeText(question_answer.question);

    // Check if the normalized question text matches or contains the normalized question answer
    if (normalizedQuestionAnswer.includes(normalizedQuestionText) || normalizedQuestionAnswer == normalizedQuestionText) {
        return question_answer.answer_xpath || {};
    }

    // Return an empty object if the condition does not match
    return {};
}

export default Flow;

// Function to extract form questions from the web page
async function extractFormQuestions(step) {
    // Initialize an array to hold the details of matched elements
    const inputFieldDetails = [];

    // Find the form element using the provided XPath
    const formElement = document.evaluate(step.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

    // Check if the formElement is found
    if (formElement) {
        // Evaluate the XPath expression within the context of formElement
        const iterator = document.evaluate(step.fieldElementXPath, formElement, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
        let node = iterator.iterateNext();

        // Iterate over the matched nodes
        while (node) {
            // Extract the validation error
            const validationErrorNode = document.evaluate(step.validationErrorXPath, node, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            const validationError = validationErrorNode ? validationErrorNode.textContent.trim() : "";

            if (!validationError) {
                node = iterator.iterateNext();
                continue;
            }

            let options = [];

            // Extract the field type
            const fieldTypeNode = document.evaluate(step.fieldTypeXPath, node, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            let fieldType = fieldTypeNode ? fieldTypeNode.getAttribute('type') || fieldTypeNode.tagName.toLowerCase() : "text";

            // Handle radio buttons
            if (fieldType === 'radio') {
                const radioGroupNode = document.evaluate(step.radioElementXpath, node, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                if (window.location.hostname.includes('indeed.com')) {
                    const radioNodeLabel = document.evaluate(step.radioFieldXpath, node, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                    let radioNode = radioNodeLabel.iterateNext();
                    while (radioNode) {
                        const label = document.evaluate(step.radioElementLabelXpath, radioNode, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                        options.push(label.textContent.trim());
                        radioNode = radioNodeLabel.iterateNext();
                    }
                } else {
                    const radioIterator = document.evaluate(step.radioElementLabelXpath, radioGroupNode, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                    let radioNode = radioIterator.iterateNext();
                    while (radioNode) {
                        options.push(radioNode.textContent.trim());
                        radioNode = radioIterator.iterateNext();
                    }
                }
            }

            // Handle dropdowns
            if (fieldType === 'select') {
                fieldType = 'dropdown';
                const optionsIterator = document.evaluate('.//option', fieldTypeNode, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
                let optionNode = optionsIterator.iterateNext();
                while (optionNode) {
                    options.push(optionNode.textContent.trim());
                    optionNode = optionsIterator.iterateNext();
                }
            }

            // Extract the label
            const labelNode = document.evaluate(step.labelXPath, node, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            const label = labelNode ? labelNode.textContent.trim() : null;

            // Move to the next node
            node = iterator.iterateNext();

            // Push the extracted details to the array
            inputFieldDetails.push({
                question: label,
                answer_type: fieldType || 'text',
                instruction: validationError || "",
                options,
            });
        }
    }
    return inputFieldDetails;
}

// Function to prefill the form with AI responses
function prefillFormWithResponses(step, questions, formQuestions) {
    // Find the form element using the provided XPath
    const prefillFormElement = document.evaluate(step.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    let prefillResponse = { reason: '', response: "success" };

    if (prefillFormElement) {
        // Use an ordered node snapshot to avoid DOM mutation issues
        const prefillSnapshot = document.evaluate(step.fieldElementXPath, prefillFormElement, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);

        // Iterate over the snapshot
        for (let i = 0; i < prefillSnapshot.snapshotLength; i++) {
            const prefillNode = prefillSnapshot.snapshotItem(i);

            // Extract the validation error
            const validationErrorNode = document.evaluate(step.validationErrorXPath, prefillNode, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            const validationError = validationErrorNode ? validationErrorNode.textContent.trim() : "";

            if (!validationError) continue;

            // Extract the field type node
            const fieldTypeNode = document.evaluate(step.fieldTypeXPath, prefillNode, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            const fieldType = fieldTypeNode ? fieldTypeNode.getAttribute('type') || fieldTypeNode.tagName.toLowerCase() : null;

            // Extract the label node
            const labelNode = document.evaluate(step.labelXPath, prefillNode, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

            // Find the response by matching the question index of the corresponding label
            const matchedFormQuestion = formQuestions.find((field) => field.question.trim().toLowerCase() === labelNode.textContent.trim().toLowerCase());
            const currentFileResponse = questions.find((field) => field.index === matchedFormQuestion.index);

            if (!currentFileResponse || !currentFileResponse?.value?.length || currentFileResponse?.value.toLowerCase() === 'not found in resume') {
                prefillResponse = { reason: `Answer not found in resume for the Question: ${labelNode.textContent.trim()}`, response: false };
                break;
            }

            // Handle the input based on its type
            if (fieldTypeNode) {
                // Handle radio buttons
                if (fieldType === 'radio') {
                    const radioIterator = document.evaluate(step.radioFieldXpath, prefillNode, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                    for (let j = 0; j < radioIterator.snapshotLength; j++) {
                        let radioNode = radioIterator.snapshotItem(j);
                        const radioNodeLabel = document.evaluate(step.radioElementLabelXpath, radioNode, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                        if (radioNodeLabel?.textContent.trim() === currentFileResponse.value) {
                            const radioInputField = document.evaluate(step.radioElementInputXpath, radioNode, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                            if (radioInputField) radioInputField.click();
                            break;
                        }
                    }
                    continue;
                }

                // Handle dropdowns
                if (fieldType === 'select' || fieldType === 'dropdown') {
                    const selectFieldIterator = document.evaluate(step.selectFieldXpath, prefillNode, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                    for (let j = 0; j < selectFieldIterator.snapshotLength; j++) {
                        let selectFieldNode = selectFieldIterator.snapshotItem(j);
                        if (selectFieldNode) {
                            const options = selectFieldNode.options;
                            for (let i = 0; i < options.length; i++) {
                                if (options[i].textContent.trim() === currentFileResponse.value || options[i].value === currentFileResponse.value) {
                                    selectFieldNode.focus();
                                    selectFieldNode.click();
                                    selectFieldNode.selectedIndex = i;

                                    const event = new Event('change', { bubbles: true });
                                    selectFieldNode.dispatchEvent(event);
                                    break;
                                }
                            }
                        }
                    }
                    continue;
                }

                // Handle text inputs
                fieldTypeNode.focus();
                const valueToFill = currentFileResponse ? String(currentFileResponse.value) : '0';

                for (const char of valueToFill) {
                    const keyboardEvent = new KeyboardEvent('keydown', {
                        key: char,
                        char: char,
                        keyCode: char.charCodeAt(0),
                        which: char.charCodeAt(0),
                        bubbles: true
                    });
                    fieldTypeNode.dispatchEvent(keyboardEvent);
                    fieldTypeNode.value += char;
                    const inputEvent = new Event('input', { bubbles: true });
                    fieldTypeNode.dispatchEvent(inputEvent);
                }

                const changeEvent = new Event('change', { bubbles: true });
                fieldTypeNode.dispatchEvent(changeEvent);
            }
        }
        return prefillResponse;
    }
}
