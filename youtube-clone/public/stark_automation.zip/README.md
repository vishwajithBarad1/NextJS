npx webpack --mode production
npx webpack --mode development