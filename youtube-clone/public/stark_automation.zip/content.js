const PORTAL_URL = 'https://stark.ai';
// const PORTAL_URL = 'http://127.0.0.1:8000';
// Print a nice message to know that Stark is around
console.log('Howdy from Stark!!');

//////////////////////////////////////////////////// Listener //////////////////////////////////////////////////////

/**
 * Listener for messages from the background script.
 * Handles initialization of worker and other actions if needed.
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Content Script - Received', request);
    if (request.action === 'init_worker') {
        displayMessageBox('info', 'Stark.ai has opened this window to manage your auto application process');
        sendResponse({ status: 'initialized' });

        // We will also show code to alert the user telling that he does not have to close this and Stark is handling it
        window.addEventListener('beforeunload', event => {
            alert('Your request is being processed by Stark. Please do not close this tab.'); // Alert the user
            const confirmationMessage = 'Your request is being processed by Stark. Please do not close this tab.';
            (event || window.event).returnValue = confirmationMessage; // Standard for most browsers
            return confirmationMessage; // For some browsers
        });
    } else if (request.action === 'display_processing_message') {
        displayStarkProcessingMessage();
    } else if (request.action === 'update_job_status') {
        // Dispatch event to update job status in auto apply dashboard for stark tabs
        document.dispatchEvent(new CustomEvent('updateJobStatus', { detail: { ...request } }));
    }
    return true; // Keep the message channel open for sendResponse
});

//////////////////////////////////////////////////// Initial Load Checks //////////////////////////////////////////////////////

// Listen for URL changes of the portals and show message box
window.navigation.addEventListener('navigate', function () {
    // Remove the message box before adding another one
    const oldMessageBox = document.querySelector('.message-box');
    if (oldMessageBox) {
        oldMessageBox.remove();
    }

    chrome.runtime.sendMessage({ src: 'contentScript', action: 'get_portal_user_info' }, response => {
        checkURL(window.location.href, response.portals_info, response.access_token);
    });
});

// Initial URL check on load
chrome.runtime.sendMessage({ src: 'contentScript', action: 'get_portal_user_info' }, response => {
    checkURL(window.location.href, response.portals_info, response.access_token);
});

//////////////////////////////////////////////////// Website to CONTENT SCRIPT //////////////////////////////////////////////////////

/**
 * Listener for messages from the webpage. Stark Message
 * Forwards the action to the background script and handles the response.
 */
window.addEventListener('message', event => {
    // Close the auto apply iframe upon listening event from iframe

    if (event.data.type === 'close-auto-apply-iframe') {
        return document.getElementById('auto-apply-iframe-close-btn')?.click();
    }
    // Ensures the message is from the same window and is a request.
    if ((event.data.action !== 'add-job-search' && event.data.action !== 'remove-job-search' && event.data.action !== 'update-active-tab') &&
        event.source !== window || event.data.type !== 'request') {
        console.log("Request not from the same window", event)
        return;
    }

    const { action, data, requestId } = event.data;

    console.log('Content Script - Sending Event', event.data);

    // Sends the action to the background script.
    chrome.runtime.sendMessage({ action, data: data, src: 'starkAI' }, response => {
        // Received Response
        console.log('Content Script - Received', response);

        const uniqueAction = `${action}-${requestId}-response`;
        // Forwards the response back to the webpage.
        window.postMessage({ type: 'response', action: uniqueAction, requestId, response, error: chrome.runtime.lastError }, '*');
    });
});


//////////////////////////////////////////////////// End of Website to CONTENT SCRIPT //////////////////////////////////////////////////////

//////////////////////////////////////////////////// ALERTS //////////////////////////////////////////////////////

// Function to create and display the message box with callback on click
function displayMessageBox(type, message, onClick) {
    const messageBox = document.createElement('div');
    messageBox.className = 'message-box';
    messageBox.style.position = 'fixed';
    messageBox.style.top = '20px';
    messageBox.style.width = '390px';
    messageBox.style.fontWeight = '500';
    messageBox.style.lineHeight = '22px';
    messageBox.style.right = '20px';
    messageBox.style.padding = '15px';
    messageBox.style.border = '1px solid';
    messageBox.style.borderRadius = '10px';
    messageBox.style.zIndex = '9999';
    messageBox.style.display = 'flex';
    messageBox.style.alignItems = 'center';
    messageBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
    messageBox.style.cursor = onClick ? 'pointer' : 'default';
    messageBox.style.transition = 'all 0.3s ease';

    messageBox.addEventListener('mouseover', () => {
        messageBox.style.boxShadow = '0 6px 10px rgba(0, 0, 0, 0.15)';
        messageBox.style.transform = 'translateY(-2px)';
    });

    messageBox.addEventListener('mouseout', () => {
        messageBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        messageBox.style.transform = 'translateY(0)';
    });

    const closeButton = document.createElement('span');
    closeButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
    `;
    closeButton.style.cursor = 'pointer';
    closeButton.style.position = 'absolute';
    closeButton.style.top = '2px';
    closeButton.style.right = '2px';
    closeButton.style.alignSelf = 'flex-end';
    closeButton.addEventListener('click', () => {
        messageBox.remove();
    });

    const contentDiv = document.createElement('div');
    contentDiv.style.display = 'flex';
    contentDiv.style.alignItems = 'center';

    const icon = document.createElement('img');
    icon.src = `${PORTAL_URL}/static/images/stark-256.png`;
    icon.style.width = '32px';
    icon.style.height = '32px';
    icon.style.marginRight = '10px';

    const messageText = document.createElement('span');
    messageText.innerHTML = message;

    contentDiv.appendChild(icon);
    contentDiv.appendChild(messageText);

    messageBox.appendChild(closeButton);
    messageBox.appendChild(contentDiv);

    switch (type) {
        case 'success':
            messageBox.style.backgroundColor = '#4caf50';
            messageBox.style.color = '#ffffff';
            messageBox.style.borderColor = '#4caf50';
            break;
        case 'error':
            messageBox.style.backgroundColor = '#f44336';
            messageBox.style.color = '#ffffff';
            messageBox.style.borderColor = '#f44336';
            break;
        case 'warn':
            messageBox.style.backgroundColor = '#ff9800';
            messageBox.style.color = '#ffffff';
            messageBox.style.borderColor = '#ff9800';
            break;
        case 'info':
            messageBox.style.backgroundColor = '#ffffff'; // Simple white background
            messageBox.style.color = '#000000';
            messageBox.style.borderColor = '#cccccc';
            break;
        default:
            messageBox.style.backgroundColor = '#ffffff';
            messageBox.style.color = '#000000';
            messageBox.style.borderColor = '#cccccc';
    }

    if (onClick) {
        messageText.addEventListener('click', () => {
            messageBox.remove();
            onClick();
        });
    }

    document.body.appendChild(messageBox);

    return messageBox;
}
// Function to display a message that Stark is handling the auto-apply process
function displayStarkProcessingMessage() {
    // Create overlay
    const overlay = document.createElement('div');
    overlay.id = 'processing-overlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.2)'; // Light semi-transparent black
    overlay.style.zIndex = '9998';

    // Create message box
    const processingBox = document.createElement('div');
    processingBox.id = 'processing-message-box';
    processingBox.style.position = 'fixed';
    processingBox.style.top = '50%';
    processingBox.style.left = '50%';
    processingBox.style.transform = 'translate(-50%, -50%)'; // Center the box
    processingBox.style.backgroundColor = '#f39c12';
    processingBox.style.color = '#ffffff';
    processingBox.style.padding = '20px';
    processingBox.style.border = '1px solid #f39c12';
    processingBox.style.borderRadius = '10px';
    processingBox.style.zIndex = '9999';
    processingBox.style.display = 'flex';
    processingBox.style.flexDirection = 'column';
    processingBox.style.alignItems = 'center';
    processingBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

    const icon = document.createElement('img');
    icon.src = `${PORTAL_URL}/static/images/stark-256.png`;
    icon.style.width = '32px';
    icon.style.height = '32px';
    icon.style.marginBottom = '10px';

    const messageText = document.createElement('span');
    messageText.innerHTML = 'Stark is handling the auto-apply process. Please do not close this window.';

    processingBox.appendChild(icon);
    processingBox.appendChild(messageText);

    document.body.appendChild(overlay);
    document.body.appendChild(processingBox);

    // Hide all message boxes with the specified class
    const messageBoxes = document.querySelectorAll('.message-box');
    messageBoxes.forEach(box => {
        box.style.display = 'none';
    });
}
//////////////////////////////////////////////////// Version DIV //////////////////////////////////////////////////////

// We will add a small id tag for the page to detect if the extension is installed
const extensionCheckDiv = document.createElement('div');
extensionCheckDiv.id = 'stark-ai-extension';
extensionCheckDiv.style.display = 'none';
document.body.appendChild(extensionCheckDiv);

//////////////////////////////////////////////////// Check Portal and Show Messages //////////////////////////////////////////////////////

// Function to check URL and display appropriate messages
function checkURL(url, portalsInfo, accessToken) {
    console.log('Content Script', url, portalsInfo, accessToken);
    portalsInfo.forEach(portal => {
        if (url.includes(portal.base_url)) {
            const checkAndProceed = () => {
                if (url.includes(portal.jobs_path)) {
                    if (accessToken) {
                        displayMessageBox('info', 'First, select your filters (job title, location, etc.), then search for jobs. Stark.AI will auto-apply to matching jobs, and you can save and schedule your searches by clicking here.', displayAutoApplyPopup);
                        // displayAutoApplyPopup(accessToken);
                    } else {
                        displayMessageBox('warn', 'Stark.ai can auto-apply to these jobs. <br/><strong>Please signup or login to your account.</strong>');
                    }
                } else if (url.includes(portal.listing_path)) {
                    if (accessToken) {
                        setTimeout(() => {
                            const jobDescription = document.documentElement.outerHTML; // Capture the full HTML content including headers
                            chrome.runtime.sendMessage(
                                {
                                    src: 'contentScript',
                                    action: 'fetch_job_score',
                                    jobDescription: jobDescription,
                                    accessToken: accessToken,
                                    portalName: portal.name, // Include the portal name
                                },
                                response => {
                                    if (response.error) {
                                        displayMessageBox('error', `Error fetching score: ${response.error}`);
                                    } else {
                                        displayRelevanceScores(response.relevance_scores);
                                    }
                                }
                            );
                        }, 3000); // Wait for 3 seconds before capturing the HTML content
                    } else {
                        displayMessageBox('warn', 'Stark.ai can fetch the AI match score for this job against your profiles. <br/><strong>Please signup or login to your account.</strong>');
                    }
                } else {
                    displayMessageBox('info', 'Stark.ai makes job hunting easy! Simply set your filters, start your search, and watch as Stark.ai auto-applies to matching jobs.');
                }
            };

            if (portal.job_loaded_selector) {
                let elapsed = 0;
                const interval = 100;
                const maxTime = 3000;

                const intervalId = setInterval(() => {
                    if (document.querySelector(portal.job_loaded_selector) || elapsed >= maxTime) {
                        clearInterval(intervalId);
                        checkAndProceed();
                    }
                    elapsed += interval;
                }, interval);
            } else {
                checkAndProceed();
            }
        }
    });
}

function displayRelevanceScores(scores) {
    const messageBox = document.createElement('div');
    messageBox.className = 'message-box';
    messageBox.style.position = 'fixed';
    messageBox.style.top = '20px';
    messageBox.style.background = '#FFFF';
    messageBox.style.right = '20px';
    messageBox.style.minWidth = '390px';
    messageBox.style.fontWeight = '500';
    messageBox.style.lineHeight = '22px';
    messageBox.style.padding = '15px';
    messageBox.style.border = '1px solid #ccc';
    messageBox.style.borderRadius = '10px';
    messageBox.style.zIndex = '9999';
    messageBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

    const title = document.createElement('div');
    title.style.width = '100%';
    title.style.display = 'flex';
    title.style.alignItems = 'center';
    title.style.justifyContent = 'space-between';
    title.style.marginBottom = '10px';

    const titleLeft = document.createElement('div');
    titleLeft.style.display = 'flex';
    titleLeft.style.alignItems = 'center';

    const icon = document.createElement('img');
    icon.src = `${PORTAL_URL}/static/images/stark-256.png`;
    icon.style.width = '32px';
    icon.style.height = '32px';
    icon.style.marginRight = '5px';

    const name = document.createElement('div');
    name.textContent = 'Stark.ai Job Scores';
    name.style.fontSize = '16px';
    name.style.fontWeight = 'bold';

    titleLeft.appendChild(icon);
    titleLeft.appendChild(name);

    const closeButton = document.createElement('div');
    closeButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x">
            <path d="M18 6 6 18"/>
            <path d="m6 6 12 12"/>
        </svg>`;
    closeButton.style.width = '18px';
    closeButton.style.height = '18px';
    closeButton.style.cursor = 'pointer';
    closeButton.addEventListener('click', () => {
        messageBox.remove();
    });

    title.appendChild(titleLeft);
    title.appendChild(closeButton);
    messageBox.appendChild(title);

    const table = document.createElement('table');
    table.style.width = '100%';
    table.style.marginTop = '10px';

    scores.forEach(score => {
        const row = document.createElement('tr');

        const fileNameCell = document.createElement('td');
        fileNameCell.style.paddingRight = '10px';
        fileNameCell.style.color = '#3e3e3e';
        fileNameCell.style.paddingBottom = '12px';
        fileNameCell.style.fontSize = '14px';
        fileNameCell.style.fontWeight = '500';
        fileNameCell.style.display = 'block';
        fileNameCell.style.textOverflow = 'ellipsis';
        fileNameCell.style.overflow = 'hidden';
        fileNameCell.style.whiteSpace = 'nowrap';
        fileNameCell.style.width = '30ch';
        fileNameCell.textContent = score.fileName;

        const relevanceScoreCell = document.createElement('td');
        relevanceScoreCell.style.paddingLeft = '10px';
        relevanceScoreCell.style.paddingBottom = '12px';
        relevanceScoreCell.style.fontSize = '14px';
        relevanceScoreCell.style.fontWeight = '500';
        relevanceScoreCell.style.textAlign = 'right';

        // Determine color based on score
        if (score.relevance_score >= 70) {
            relevanceScoreCell.style.color = '#008000';
        } else if (score.relevance_score >= 60) {
            relevanceScoreCell.style.color = '#ff8710';
        } else {
            relevanceScoreCell.style.color = '#ff0000';
        }

        relevanceScoreCell.textContent = `${score.relevance_score}%`;

        row.appendChild(fileNameCell);
        row.appendChild(relevanceScoreCell);
        table.appendChild(row);
    });

    messageBox.appendChild(table);
    document.body.appendChild(messageBox);

    return messageBox;
}

function displayAutoApplyPopup() {
    // Create overlay
    const overlay = document.createElement('div');
    overlay.id = 'auto-apply-overlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)'; // 80% opacity black
    overlay.style.zIndex = '9998';

    // Create popup container
    const popupContainer = document.createElement('div');
    const popupContainerInner = document.createElement('div');
    popupContainerInner.style.height = '100%';
    popupContainerInner.style.position = 'relative';
    popupContainerInner.style.margin = '20px auto';
    popupContainer.id = 'auto-apply-popup';
    popupContainer.style.position = 'fixed';
    popupContainer.style.top = '50%';
    popupContainer.style.left = '50%';
    popupContainer.style.transform = 'translate(-50%, -50%)'; // Center the container
    popupContainer.style.width = 'auto';
    popupContainer.style.height = '100%';
    popupContainer.style.backgroundColor = 'transparent'; // Set background to transparent
    popupContainer.style.border = 'none'; // Remove border
    popupContainer.style.zIndex = '9999';
    popupContainer.style.display = 'flex';
    popupContainer.style.flexDirection = 'column';
    popupContainer.style.alignItems = 'center'; // Center align items

    // Create close button
    const closeButton = document.createElement('span');
    closeButton.setAttribute('id', 'auto-apply-iframe-close-btn');
    closeButton.textContent = 'x';
    closeButton.style.cursor = 'pointer';
    closeButton.style.position = 'absolute';
    closeButton.style.top = '10px';
    closeButton.style.right = '10px';
    closeButton.style.background = '#ffffff';
    closeButton.style.border = '1px solid #cccccc';
    closeButton.style.borderRadius = '5px';
    closeButton.style.padding = '5px';
    closeButton.style.zIndex = '10000';
    closeButton.addEventListener('click', () => {
        document.body.removeChild(overlay);
        document.body.removeChild(popupContainer);
        document.body.removeChild(popupContainerInner);
    });

    // Create iframe
    const iframe = document.createElement('iframe');
    const currentUrl = window.location.href;
    iframe.src = `${PORTAL_URL}/auto-apply-iframe?job=${encodeURIComponent(currentUrl)}&origin=${encodeURIComponent(window.location.origin)}`;
    // iframe.src = `http://127.0.0.1:8000/auto-apply-iframe?job=${encodeURIComponent(currentUrl)}&origin=${encodeURIComponent(window.location.origin)}`;
    iframe.style.width = '1000px';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    iframe.style.borderRadius = '10px'; // Adjust to match the container's border radius
    iframe.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

    // Append elements to the container and body
    popupContainer.appendChild(popupContainerInner);
    popupContainerInner.appendChild(closeButton);
    popupContainerInner.appendChild(iframe);
    document.body.appendChild(overlay);
    document.body.appendChild(popupContainer);
}
