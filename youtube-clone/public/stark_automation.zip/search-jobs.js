import { getJobSearchURLs, getJobsFromSearch } from './utils.js';
class SearchJobs {
  constructor(portal, token, tab, searchPrefs) {
    this.portal = portal;
    this.token = token;
    this.tab = tab;
    this.prefs = searchPrefs;
    this.maxSearchJobs = 400;
  }

  removeDuplicates(original_list, sub_list, resume, jobSearchURL, apply_prefs) {
    let firstSearch = false;
    if (!original_list) {
      firstSearch = true;
      original_list = [];
    }
    const newJobsList = []
    const url_list = original_list?.map(job => job.url);

    sub_list.forEach(job_data => {
      if (!url_list.includes(job_data.url)) {
        job_data = { ...job_data, ...apply_prefs };
        job_data.profile_uuid = resume.uuid;
        job_data.type = 'auto_apply';
        
        // Push new jobs with high priority as per the preference
        if (this.prefs.applyLatestJobs)
            job_data.priority = firstSearch ? 10 : 0;
        else
            job_data.priority = 10

        job_data.searchUrl = jobSearchURL;
        newJobsList.push(job_data);
        url_list.push(job_data.url);
      }
    });

    return [...original_list, ...newJobsList];
  }

  async exec_search_jobs({ matchScore, jobUrl: job_search_url, resume: resume }) {
    const timeoutDuration = 5 * 60 * 1000; // 5 minutes in milliseconds

    const createTimeoutPromise = (timeout) => new Promise((resolve) => {
      setTimeout(() => {
        resolve([]); // Resolve with an empty array after the timeout
      }, timeout);
    });

    const page_urls = await Promise.race([
      getJobSearchURLs(this.tab.id, job_search_url, this.portal, 0, this.maxSearchJobs, this.token),
      createTimeoutPromise(timeoutDuration),
    ]);

    const jobs_data = await Promise.race([
      getJobsFromSearch(this.tab.id, page_urls, this.portal, this.token),
      createTimeoutPromise(timeoutDuration),
    ]);

    const jobKey = `job-listing-${this.portal}-${resume.uuid}-${job_search_url}`;
    console.log("jobs fetched data -", jobs_data, page_urls);

    const { [jobKey]: data } = await chrome.storage.local.get(jobKey);
    const searchedJobs = this.removeDuplicates(data, jobs_data, resume, job_search_url, { matchScore });

    console.log("Jobs pushed to the store", searchedJobs);
    await chrome.storage.local.set({ [jobKey]: searchedJobs });

    return searchedJobs;
  }

}

export { SearchJobs };
