// Import necessary functions and constants from utils.js
import { getAccessToken, getUserData, PORTALS_URL } from './utils.js';

let resumeData

// Event listener for when the DOM content is loaded
document.addEventListener('DOMContentLoaded', async function () {
    // Set the href attribute of the explore link
    const link = document.getElementById('explore-link');
    link.href = PORTALS_URL;

    // Get access token
    const token = await getAccessToken();
    // If no token, show empty state and return
    if (!token) {
        showEmptyState();
        return;
    }

    // Get user data using the token
    const userData = await getUserData(token, true);
    // If no user data or resume data, return
    if (!userData || !userData.resumeData) return;

    // Set user data in the UI
    setUserData(userData);

    // Parse resume data
    resumeData = JSON.parse(userData.resumeData);
    // If no resume data, return
    if (resumeData.length === 0) return;

    // Render profiles and update portals and job searches
    const profilesContainer = document.getElementById('profiles');
    profilesContainer.innerHTML = '';
    resumeData.forEach((profile, index) => {
        const profileElement = createProfileElement(profile, index);
        profilesContainer.appendChild(profileElement);
    });
    console.log("resumeData", resumeData);

    // Update portals and job searches for the first profile
    updatePortalsAndJobSearches(resumeData[0]);
});


// Function to show the empty state in the UI
function showEmptyState() {
    const container = document.querySelector('.data-container');
    container.innerHTML = `
        <div class="main-body p-4 pb-0 bg-[#fffbef52] mt-[60px] ">
            <div class="flex items-center justify-center flex-col before-login">
                <div class="">
                    <img src="/icons/extension-svg-1.svg" class="w-64" alt="Stark Extension" />
                </div>
                <p class="text-sm text-center my-4 font-semibold text-neutral-900">
                    Wonderful ! Stark.ai is now installed. <br />
                </p>
                <p class="text-xs text-center text-neutral-700 mb-8 mx-10">
                    Head over to the job portals to start auto-applying instantly!
                </p>
                <a href="${PORTALS_URL}" target="_blank">
                    <div class="bg-black text-white opacity-90 hover:opacity-80 inline-block capitalize text-sm font-medium rounded-md py-2 px-5 transition duration-500 ease-in-out">
                        Let's Get Started
                    </div>
                </a>
            </div>
        </div>
    `;
}


// Function to set user data in the UI
function setUserData(userData) {
    // Set user name and email in the UI
    document.getElementById('userName').innerText = userData.name || 'Anonymous';
    document.getElementById('userEmail').innerText = userData.email || 'No Email';
}

// Function to create profile element
function createProfileElement(profile, index) {
    // Create profile element and add event listener
    const profileElement = document.createElement('div');
    profileElement.className = `rounded text-xs px-2 py-1.5 cursor-pointer truncate ${index === 0 ? 'bg-white shadow-md text-neutral-900' : 'text-neutral-500 hover:bg-white/40  hover:text-neutral-700 '}`;
    profileElement.innerText = profile.fileName;
    profileElement.addEventListener('click', () => {
        document.querySelectorAll('#profiles div').forEach(el => {
            el.classList.remove('bg-white', 'text-neutral-900', 'shadow-md');
            el.classList.add('text-neutral-500');
        });
        profileElement.classList.remove('text-neutral-500');
        profileElement.classList.add('bg-white', 'text-neutral-900', 'shadow-md');
        updatePortalsAndJobSearches(profile);
    });
    return profileElement;
}

// Function to update portals and job searches
function updatePortalsAndJobSearches(profile) {
    // Update portals UI and job searches for the selected profile
    const portalsContainer = document.getElementById('portals');
    portalsContainer.innerHTML = '';

    const portals = Object.keys(profile?.autoApply || {});
    portals.unshift('All');

    portals.forEach(portal => {
        const portalElement = createPortalElement(portal);
        portalElement.addEventListener('click', () => {
            document.querySelectorAll('#portals div').forEach(ele => ele.classList.remove('text-gray-900', 'border-b', 'border-gray-600', 'font-medium'));
            portalElement.classList.add('text-gray-900', 'border-b', 'border-gray-600', 'font-medium');
            updateJobSearches(profile, portal);
        });
        portalsContainer.appendChild(portalElement);
    });

    updateJobSearches(profile, 'All');
}

// Function to create portal element
function createPortalElement(portal) {
    // Create portal element and add event listener
    const portalElement = document.createElement('div');
    portalElement.className = 'text-xs text-gray-500 px-3 py-1.5 rounded-t-sm  cursor-pointer capitalize';
    portalElement.id = `${portal}-tab`
    if (portal == 'All') {
        portalElement.classList.add('text-gray-900', 'border-b', 'border-gray-500', 'font-medium');
    }
    portalElement.innerText = portal;
    return portalElement;
}

// Function to update job searches
async function updateJobSearches(profile, selectedPortal) {
    const jobSearchesContainer = document.getElementById('jobSearches');
    jobSearchesContainer.innerHTML = '';

    // Retrieve jobs based on selected portal
    const portalJobs = selectedPortal === 'All' ?
        Object.entries(profile.autoApply).flatMap(([portal, data]) =>
            data.job_urls.map(job => ({ job, portal }))
        ) :
        profile.autoApply[selectedPortal]?.job_urls.map(job => ({ job, portal: selectedPortal })) || [];

    // Iterate through jobs
    for (const { job, portal } of portalJobs) {
        // Update counts and get jobs yet to apply
        const counts = await updateCounts(job, portal, profile);
        const yetToApply = await getYetToApplyJobs(portal, job);

        // Skip to the next iteration if there are no jobs to display
        if (!(counts?.applied || counts?.failed || yetToApply)) continue;

        // Create job search element
        jobSearchesContainer.appendChild(createJobSearchElement(job, portal, profile, { ...counts, yetToApply, total: counts.applied + counts.failed + yetToApply }));
    }

    // Update total summary
    updateTotalSummary();
}

// Function to delete search URL
async function deleteSearchURL(profileId, searchUrl, portalName) {
    const profile = resumeData.find(resume => resume.uuid === profileId);
    const profileIndex = profile.autoApply?.[portalName]?.job_urls?.findIndex(job => job.jobUrl === searchUrl);

    if (profileIndex > -1) {
        profile?.autoApply?.[portalName]?.job_urls?.splice(profileIndex, 1);

        if (!profile?.autoApply?.[portalName]?.job_urls?.length)
            delete profile?.autoApply?.[portalName];

        const jobURLEle = document.getElementById(`job-search-${profileId}-${portalName}-${searchUrl}`);
        jobURLEle.remove();

        // Update data and notify background script
        await fetch(`${PORTALS_URL}/profile/`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ key: "resumeData", value: JSON.stringify(resumeData) }),
        });
        chrome.runtime.sendMessage({ action: "remove-job-search", data: { portal: portalName, jobSearchUrl: searchUrl, profile } });

        // Remove tab if no job searches left
        const jobSearchEle = document.querySelectorAll('[id*="job-search"]');
        if (!jobSearchEle?.length) {
            const portalTabElement = document.getElementById(`${portalName}-tab`);
            document.getElementById('portals').removeChild(portalTabElement);
            document.getElementById(`All-tab`).classList.add('text-gray-900', 'border-b', 'border-gray-600', 'font-medium');
            updateJobSearches(profile, 'All');
        }
    }
}

// Function to create job search element
function createJobSearchElement(job, portal, profile, counts) {
    const searchElement = document.createElement('div');
    searchElement.id = `job-search-${profile.uuid}-${portal}-${job.jobUrl}`;
    searchElement.className = 'mb-2 rounded border text-left text-sm transition-all';

    // Populate job search element with counts
    searchElement.innerHTML = `
        <div class="flex items-center rounded gap-2 border-b border-gray-200">
            <input type="text" value="${job.jobUrl}" readonly class="flex-1 p-2 text-gray-500 rounded text-small focus:outline-none">
            <button class="text-xs p-2 border-l border-gray-200" id="deleteSearchBtn">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff5454" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trash-2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
            </button>
        </div>
        <div class="grid grid-cols-2 gap-1 text-small p-1.5">
            <div id="total-jobs" data-value="${counts.total}" class="bg-blue-50 bg-opacity-70 text-blue-600 p-2 rounded capitalize">Total Jobs Searched: ${counts.total}</div>
            <div id="applied-jobs" data-value="${counts.applied}" class="bg-green-50 bg-opacity-70 text-green-600 p-2 rounded capitalize">Jobs Applied: ${counts.applied}</div>
            <div id="yet-to-apply-jobs" data-value="${counts.yetToApply}" class="bg-yellow-50 text-yellow-600 p-2 rounded capitalize">Yet to Apply: ${counts.yetToApply}</div>
            <div id="failed-jobs" data-value="${counts.failed}" class="bg-red-50 bg-opacity-70 text-red-600 p-2 rounded capitalize">Failed: ${counts.failed}</div>
        </div>
    `;

    // Attach delete button listener
    searchElement.querySelector('#deleteSearchBtn').addEventListener('click', () => {
        deleteSearchURL(profile.uuid, job.jobUrl, portal);
    });

    return searchElement;
}

// Function to update job search counts
async function updateCounts(job, portal, profile) {
    try {
        const response = await fetch(`${PORTALS_URL}/jobs/search`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ portal, profile: profile.uuid, search_url: job.jobUrl })
        });

        if (response.ok) {
            const data = await response.json();
            const appliedJobs = data.jobsStatus.filter(item => item.status.toLowerCase() == 'applied').length;
            const failedJobs = data.jobsStatus.filter(item => item.status.toLowerCase() !== 'applied').length;
            return { applied: appliedJobs, failed: failedJobs };
        } else {
            const jobSearchesContainer = document.getElementById('jobSearches');
            const searchElement = document.getElementById(`job-search-${profile.uuid}-${portal}-${job.jobUrl}`);
            if (searchElement) jobSearchesContainer.removeChild(searchElement);
        }
    } catch (error) {
        const jobSearchesContainer = document.getElementById('jobSearches');
        const searchElement = document.getElementById(`job-search-${profile.uuid}-${portal}-${job.jobUrl}`);
        if (searchElement) jobSearchesContainer.removeChild(searchElement);
    }
    return { applied: 0, failed: 0 };
}

// Function to get jobs yet to apply
async function getYetToApplyJobs(portal, job) {
    return await new Promise(resolve => {
        chrome.runtime.sendMessage({ action: "get_pending_jobs", data: { portal, searchUrl: job.jobUrl } }, response => {
            resolve(response.scheduledJobs.length);
        });
    });
}

// Function to update total summary
function updateTotalSummary() {
    const status = ['applied', 'failed', 'total', 'yet-to-apply'];
    const summaryCount = { applied: 0, failed: 0, total: 0, 'yet-to-apply': 0 };

    // Calculate total counts
    status.forEach(type => {
        const elements = document.querySelectorAll(`[id*='${type}-jobs']`);
        elements?.forEach(element => {
            summaryCount[type] += Number(element?.dataset?.value);
        });
    });

    // Update summary elements
    status.forEach(type => {
        const elements = document.querySelectorAll(`[id*='${type}-summary']`);
        elements.forEach(element => {
            element.innerText = `${type === 'total' ? 'Total Jobs Searched' : (type === 'yet-to-apply' ? 'Yet to Apply' : type)}: ${summaryCount[type]}`;
        });
    });
}

