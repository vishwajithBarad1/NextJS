const PORTALS_URL = 'https://stark.ai';
// const PORTALS_URL = 'http://127.0.0.1:8000';

const AUTO_APPLY_FAILURE_REASONS = {
  not_logged_in: "Not logged in",
  job_expired: "Job expired",
  company_website: "Apply on company website manually",
  limit_exceeded: "Job apply limit exceeded",
  apply_not_found: "Apply button not found",
  unable_to_complete: "Unable to complete auto apply",
  resume_not_found: "Resume not found"
}

function downloadPortalsInfo() {
  fetch(`${PORTALS_URL}/portals/info`)
    .then(response => response.json())
    .then(data => {
      chrome.storage.local.set({ portals_info: data });
    })
    .catch(error => {
      console.error('Error downloading portal info:', error);
    });
}

function fetchRequest(endpoint, payload) {
  const apiUrl = `${PORTALS_URL}${endpoint}`;
  return fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    credentials: 'include',
  }).then(response => response.json());
}

async function getStarkAccessToken(sendResponse) {
  const urls = [PORTALS_URL];
  let cookiesRetrieved = 0;
  let accessToken = null;
  let responseSent = false;

  urls.forEach(url => {
    chrome.cookies.get({ url, name: 'access_token' }, cookie => {
      cookiesRetrieved += 1;
      if (cookie && cookie.value && !responseSent) {
        accessToken = cookie.value;
        responseSent = true;
        sendResponse({ accessToken });
      } else if (cookiesRetrieved === urls.length && !responseSent) {
        sendResponse({ accessToken });
      }
    });
  });
}

async function getAccessToken() {
  const urls = [PORTALS_URL];
  for (let url of urls) {
    const cookie = await chrome.cookies.get({ url, name: 'access_token' });
    if (cookie && cookie.value) {
      return cookie.value;
    }
  }
  return null;
}

function getUserData(accessToken, forceRefresh = false) {
  const userDataKey = 'userData';
  const accessTokenKey = 'accessToken';

  return new Promise((resolve, reject) => {
    chrome.storage.local.get([userDataKey, accessTokenKey], result => {
      const cachedData = result[userDataKey];
      const cachedToken = result[accessTokenKey];

      if (cachedToken === accessToken && cachedData && !forceRefresh) {
        resolve(JSON.parse(cachedData));
      } else {
        fetch(`${PORTALS_URL}/profile`, {
          headers: { Authorization: `Bearer ${accessToken}` },
        })
          .then(response => response.json())
          .then(data => {
            chrome.storage.local.set(
              {
                [userDataKey]: JSON.stringify(data),
                [accessTokenKey]: accessToken,
              },
              () => {
                resolve(data);
              }
            );
          })
          .catch(error => {
            reject(error);
          });
      }
    });
  });
}

async function enableFocusEmulation(tabId) {
    return new Promise((resolve, reject) => {
        chrome.debugger.sendCommand({ tabId: tabId }, 'Emulation.setFocusEmulationEnabled', { enabled: true }, (response) => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError.message);
            } else {
                resolve(response);
            }
        });
    });
}



function getHTML(tabId, url) {
    return new Promise((resolve, reject) => {
        const processTab = (tab) => {
            const listener = async (updatedTabId, changeInfo) => {
                if (updatedTabId === tab.id && changeInfo.status === 'complete') {
                    // Send message to display processing message
                    chrome.tabs.sendMessage(tab.id, {
                        action: 'display_processing_message',
                    });

                    // Emulate focus if URL is of linkedIn portal
                    if (url.includes('https://www.linkedin.com'))
                        try {
                            await enableFocusEmulation(updatedTabId)
                        } catch (e) { }

                    setTimeout(() => {
                        chrome.scripting.executeScript(
                            {
                                target: { tabId: tab.id, allFrames: false },
                                func: scrapeHTML,
                            },
                            results => {
                                if (results && results.length > 0) {
                                    resolve({
                                        tabId: tab.id,
                                        url: url,
                                        html: results[0].result,
                                    });
                                } else {
                                    reject({
                                        tabId: tab.id,
                                        url: url,
                                        error: 'Failed to retrieve HTML content',
                                    });
                                }
                                chrome.tabs.onUpdated.removeListener(listener);
                                if (!tabId) chrome.tabs.remove(tab.id);
                            }
                        );
                    }, 5000);
                }
            };
            chrome.tabs.onUpdated.addListener(listener);
            chrome.tabs.update(tab.id, { url: url, active: false });
        };

        if (tabId) {
            chrome.tabs.get(tabId, tab => {
                if (tab) {
                    processTab(tab);
                } else {
                    reject({ error: 'Tab not found' });
                }
            });
        } else {
            chrome.tabs.create({ url: url, active: false }, tab => {
                if (tab) {
                    processTab(tab);
                } else {
                    reject({ error: 'Failed to create tab' });
                }
            });
        }
    });
}

async function scrapeHTML() {
    // Check if the current page is LinkedIn else return the entire HTML content of the page
    if (!window.location.hostname.includes('linkedin'))
        return document.documentElement.outerHTML;

    // Find the jobs list element
    const jobListElement = document.querySelector('.jobs-search-results-list');

    // If job list element doesn't exist or is fully scrolled, return the entire HTML content of the page
    if (!jobListElement || jobListElement.clientHeight >= jobListElement.scrollHeight) {
        return document.documentElement.outerHTML;
    }

    // Function to wait for an element to appear using MutationObserver
    async function waitFor(mutationElement, timeout = 5000) {
        return new Promise(resolve => {
            let observer;

            // Function to handle mutation events
            const mutationHandler = () => {
                // Disconnect observer
                observer.disconnect();
                // Resolve the promise indicating content is loaded
                resolve(true);
            };

            // Create a MutationObserver to watch for changes in mutationElement
            observer = new MutationObserver(mutationHandler);
            observer.observe(mutationElement, { childList: true, subtree: true });

            // Set timeout to reject the promise if content doesn't load within timeout
            setTimeout(() => {
                observer.disconnect();
                resolve(false);
            }, timeout);
        });
    }

    // Get the total height of the job list element
    let totalHeight = jobListElement.scrollHeight;

    // Set the initial scroll position to the top of the job list element
    let currentPosition = 0;

    // Scroll the job list element until the end is reached
    while (currentPosition < totalHeight) {
        // Simulate scrolling by updating the scroll position
        jobListElement.scrollTo(0, currentPosition);

        // Wait for content to load after each scroll
        await waitFor(jobListElement, 2000);

        // Update the total height of the job list element after potential content load
        totalHeight = jobListElement.scrollHeight;

        // Update the current scroll position with a random increment between 200 and 500 pixels
        currentPosition += Math.floor(Math.random() * (500 - 200 + 1)) + 200;
    }

    // Wait after complete scrolling to ensure all content is loaded
    await waitFor(jobListElement, 2000);

    // Return the entire HTML content of the page
    return document.documentElement.outerHTML;
}


 async function fetchJobScore(request) {
  const apiUrl = `${PORTALS_URL}/ai/job-score`;
  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      job_html: request.jobDescription,
      portal: request.portalName,
      access_token: request.accessToken,
      resume_text: request.resume_text,
    }),
    credentials: 'include',
  });

  if (!response.ok) {
    throw new Error('Failed to fetch job score');
  }

  return await response.json();
}

async function getJobSearchURLs(tabId, job_search_url, portal, num_pages, num_jobs, token) {
    const pageHtml = await getHTML(tabId, job_search_url);

    const page_urls = await fetchRequest('/portals/job-urls', {
        first_page: job_search_url,
        portal: portal,
        num_pages: num_pages,
        num_jobs: num_jobs,
        html: pageHtml.html,
        access_token: token,
    });
    return page_urls
}

async function getJobsFromSearch(tabId, pageUrls, portal, token) {
  let jobs_data = [];

  for (let i = 0; i < pageUrls.length; i++) {
    const pageHtml = await getHTML(tabId, pageUrls[i]);
    const jobs = await fetchRequest('/portals/jobs-from-html', {
      html: pageHtml.html,
      portal: portal,
      access_token: token,
    });

    jobs.forEach(job => {
      job.priority = 10;
    });

    jobs_data.push(...jobs);
  }

  return jobs_data;
}

async function clearAllLocks(portals) {
  for (let portal of portals) {
    const storageKey = `stark-jobs-${portal}-lock`;
    await new Promise(resolve => {
      chrome.storage.local.set({ [storageKey]: null }, () => {
        resolve();
      });
    });
  }
}

async function clearPortalLock(portal) {
    const storageKey = `stark-jobs-${portal}-lock`;
    await new Promise(resolve => {
        chrome.storage.local.set({ [storageKey]: null }, () => {
            resolve();
        });
    });
}

async function getStarkTabs() {
    const starkUrls = [`${PORTALS_URL}/*`];
    return await chrome.tabs.query({ url: starkUrls })
}

function isYesterdayOrOlder(timestamp) {
  const currentDate = new Date();
  const timestampDate = new Date(timestamp);

  return (
    currentDate.getDate() !== timestampDate.getDate() ||
    currentDate.getMonth() !== timestampDate.getMonth() ||
    currentDate.getFullYear() !== timestampDate.getFullYear()
  );
}

export {
  downloadPortalsInfo,
  fetchRequest,
  getStarkAccessToken,
  getAccessToken,
  getUserData,
  getHTML,
  getJobSearchURLs,
  getJobsFromSearch,
  fetchJobScore,
  clearAllLocks,
  clearPortalLock,
  getStarkTabs,
  isYesterdayOrOlder,
  PORTALS_URL,
  AUTO_APPLY_FAILURE_REASONS,
};
