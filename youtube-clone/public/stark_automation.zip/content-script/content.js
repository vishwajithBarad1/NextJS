import PortalManager from './aggregators/PortalManager.js';

/**
 * Listener for messages from the background script.
 * Handles initialization of worker and other actions if needed.
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'init_worker') {
    // Initializes the worker by setting the page content.
    displayMessageBox('Stark.ai has opened this window to manage your auto application process');
    sendResponse({ status: 'initialized' });
  } else if (request.action === 'get_job_details') {
    const portal = PortalManager.getPortalInstance();
    portal
      .getJobDetails()
      .then(jobDetails => sendResponse({ jobDetails }))
      .catch(error => sendResponse({ error: error.message }));
    return true; // Indicates we will respond asynchronously
  } else if (request.action === 'apply_job') {
    const portal = PortalManager.getPortalInstance();
    const { job, profileId, tabId } = request;
    portal
      .apply(job, tabId, profileId)
      .then(response => {
        response.url = job.url;
        chrome.storage.local.set({[`STARK_AUTO_APPLY_${tabId}`]:""})
        chrome.runtime.sendMessage({ action: 'apply_job_done', url: response.url, message: response, success: true });
      })
      .catch(error => {
        chrome.storage.local.set({[`STARK_AUTO_APPLY_${tabId}`]:""})
        chrome.runtime.sendMessage({ action: 'apply_job_done', url: response.url, success: false, message: error.message });
      });
    return true; // Indicates we will respond asynchronously
  } else if (request.action === 'display_processing_message') {
    portal.getName()!== 'Internshala' && displayProcessingMessage();
  } else if (request.action === 'associate_profiles') {
    // Dispatch event to associate profile blocks
    console.log("Dispatching event associate", request)
    document.dispatchEvent(new CustomEvent('associateProfiles', {url: request.url, profile: request.profile}));
  }
});

/**
 * Listener for messages from the webpage.
 * Forwards the action to the background script and handles the response.
 */
window.addEventListener('message', event => {
  // Ensures the message is from the same window and is a request.
  if (event.source !== window || event.data.type !== 'request') {
    return;
  }

  const { action, data, requestId } = event.data;

  // Sends the action to the background script.
  chrome.runtime.sendMessage({ action, data: data }, response => {
    // Received Response
    //  console.log('Content Script - Received', response);
    if (!response) console.log('no idea why it is null');
    const uniqueAction = `${action}-${requestId}-response`;
    // Forwards the response back to the webpage.
    window.postMessage({ type: 'response', action: uniqueAction, requestId, response, error: chrome.runtime.lastError }, '*');
  });
});

// Print a nice message to know that Stark is around
console.log('Howdy from Stark!!');

// Function to create and display the message box
function displayMessageBox(message) {
  const messageBox = document.createElement('div');
  messageBox.className = 'message-box';
  messageBox.style.position = 'fixed';
  messageBox.style.top = '20px';
  messageBox.style.right = '20px';
  messageBox.style.backgroundColor = '#ffffff';
  messageBox.style.color = '#000000';
  messageBox.style.padding = '10px';
  messageBox.style.border = '1px solid #cccccc';
  messageBox.style.borderRadius = '5px';
  messageBox.style.zIndex = '9999';
  messageBox.style.display = 'flex';
  messageBox.style.alignItems = 'center';
  messageBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

  const icon = document.createElement('img');
  icon.src = 'https://v2.stark.ai/static/images/stark-256.png';
  icon.style.width = '32px';
  icon.style.height = '32px';
  icon.style.marginRight = '10px';

  const messageText = document.createElement('span');
  messageText.innerHTML = message;

  const closeButton = document.createElement('span');
  closeButton.textContent = 'x';
  closeButton.style.marginLeft = '10px';
  closeButton.style.cursor = 'pointer';
  closeButton.addEventListener('click', () => {
    messageBox.remove();
  });

  messageBox.appendChild(icon);
  messageBox.appendChild(messageText);
  messageBox.appendChild(closeButton);

  document.body.appendChild(messageBox);

  return messageBox;
}

// Function to display a message that Stark is handling the auto-apply process
function displayProcessingMessage() {
  // Create overlay
  const overlay = document.createElement('div');
  overlay.id = 'processing-overlay';
  overlay.style.position = 'fixed';
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.2)'; // Light semi-transparent black
  overlay.style.zIndex = '9998';

  // Create message box
  const processingBox = document.createElement('div');
  processingBox.id = 'processing-message-box';
  processingBox.style.position = 'fixed';
  processingBox.style.top = '50%';
  processingBox.style.left = '50%';
  processingBox.style.transform = 'translate(-50%, -50%)'; // Center the box
  processingBox.style.backgroundColor = '#f39c12';
  processingBox.style.color = '#ffffff';
  processingBox.style.padding = '20px';
  processingBox.style.border = '1px solid #f39c12';
  processingBox.style.borderRadius = '10px';
  processingBox.style.zIndex = '9999';
  processingBox.style.display = 'flex';
  processingBox.style.flexDirection = 'column';
  processingBox.style.alignItems = 'center';
  processingBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

  const icon = document.createElement('img');
  icon.src = 'https://v2.stark.ai/static/images/stark-256.png';
  icon.style.width = '32px';
  icon.style.height = '32px';
  icon.style.marginBottom = '10px';

  const messageText = document.createElement('span');
  messageText.innerHTML = 'Stark is handling the auto-apply process. Please do not close this window.';

  processingBox.appendChild(icon);
  processingBox.appendChild(messageText);

  document.body.appendChild(overlay);
  document.body.appendChild(processingBox);

  // Hide all message boxes with the specified class
  const messageBoxes = document.querySelectorAll('.message-box');
  messageBoxes.forEach(box => {
    box.style.display = 'none';
  });
}

// Ensure this function is globally available for the content script injection
window.displayProcessingMessage = displayProcessingMessage;
window.displayMessageBox = displayMessageBox;

// Initialize the portal
const portal = PortalManager.getPortalInstance();
if (portal) portal.init();

// We will add a small id tag for the page to detect if the extension is installed
const extensionCheckDiv = document.createElement('div');
extensionCheckDiv.id = 'stark-ai-extension';
extensionCheckDiv.style.display = 'none';
document.body.appendChild(extensionCheckDiv);
