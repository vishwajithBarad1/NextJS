// Internshala
import JobPortalInterface from './JobPortalInterface.js';

const xpaths = {
  login: "//div[contains(@class,'profile_icon_right')]",
  applied: "//button[contains(@class,'btn btn-large disabled')]",
  applyBtn: "//button[contains(@id,'easy_apply_button')] | //button[contains(@id,'apply_now_button')]",
  proceedBtn: "//input[contains(@name,'submit')] | //button[contains(@class,'btn btn-large education_incomplete proceed-btn')]",
  appliedStatus: "//span[contains(text(),'Go to job search')]",
  locationCheckBox: "//div[contains(text(),'This job requires you to relocate to a location outside of your current city')]//..//input[@type='checkbox']",
  locationDropDown: "//div[contains(text(),'This job requires you to relocate to a location outside of your current city')]//..//input[contains(@type,'text')]",
  dropDownOption: "//div[contains(text(),'This job requires you to relocate to a location outside of your current city')]//..//div//ul[contains(@class,'chosen-results')]//li[1]",
  responsibilities: "//h2[normalize-space()='Key responsibilities']",
  continueBtn: "//button[contains(@id,'continue_button')]",
  coverLetter: "//h4[contains(text(),'Cover letter')]",
  textInput: "//div[contains(@class,'ql-editor ql-blank')]",
  quillContainer: "//div[contains(@class,'ql-editor ql-blank')]",
  assessmentQuestion: "//div[contains(@class,'ql-editor ql-blank')] | //textarea[contains(@placeholder,'Enter text ...')]",
  submitBtn: "//input[contains(@name,'submit')]",
};
export default class Internshala extends JobPortalInterface {
  getName() {
    return 'Internshala';
  }

  getDomain() {
    return 'internshala.com';
  }

  getJobsPath() {
    return 'jobs';
  }

  getListingPath() {
    return '/internship/detail';
  }

  getDescriptionSelector() {
    return '.internship-details';
  }

  async getJobDetails() {
    const jobDetails = {
      text: document.querySelector('.internship_details')?.textContent,
    };
    return jobDetails;
  }

  async apply(job, tabId) {
    async function fillForm() {
      // Wait for the location check box to appear
      const locationCheck = await JobPortalInterface.waitFor(xpaths.locationCheckBox, 2000);

      // If the location check box exists and is not checked, click it
      if (locationCheck && !locationCheck.checked) locationCheck.click();

      // Wait for the location drop down to appear
      const locationDropDown = await JobPortalInterface.waitFor(xpaths.locationDropDown, 3000);

      // If the location check box does not exist but the drop down does, proceed
      if (!locationCheck && locationDropDown) {
        // Click the drop down to open it
        await JobPortalInterface.debuggerclickButton(tabId, xpaths.locationDropDown, 'mousePressed', 2);

        // Wait for the drop down options to appear
        const dropDownOptions = await JobPortalInterface.waitFor(xpaths.dropDownOption, 2000);

        // If drop down options exist, select one of the options
        if (dropDownOptions) {
          await JobPortalInterface.debuggerclickButton(tabId, xpaths.dropDownOption, 'mousePressed', 2);
          await JobPortalInterface.debuggerclickButton(tabId, xpaths.dropDownOption, 'mouseReleased', 2);
        }
      }

      // Wait for the responsibilities section to appear
      const responsibilities = await JobPortalInterface.waitFor(xpaths.responsibilities, 3000);

      let continueBtn;
      // If the responsibilities section exists, check for the continue button
      if (responsibilities) continueBtn = await JobPortalInterface.checkElement(xpaths.continueBtn);

      // If the continue button exists, click it
      if (continueBtn) continueBtn.click();

      // Wait for the cover letter input to appear
      const coverLetter = await JobPortalInterface.waitFor(xpaths.coverLetter, 3000);

      // If the cover letter input exists, check for the text input field
      if (coverLetter) {
        const textInput = JobPortalInterface.checkElement(xpaths.textInput);

        // If the text input field exists and has less than or equal to 10 characters, fill it with the cover letter content
        if (textInput && !(textInput.innerText?.length > 10)) await JobPortalInterface.debuggerFillInput(tabId, xpaths.quillContainer, 'Hello this is cover letter content which is a dummy text as of now', { type: 'mousePressed', inputType: 'keyDown', clickCount: 2 });
      }

      // Check for the assessment question field
      const assessmentQuestion = await JobPortalInterface.checkElement(xpaths.assessmentQuestion);

      // If the assessment question field exists and has less than or equal to 10 characters, fill it with the assessment content
      if (assessmentQuestion && !assessmentQuestion.innerText?.length > 10) await JobPortalInterface.debuggerFillInput(tabId, xpaths.assessmentQuestion, 'Hello this is assessment content which is a dummy text as of now', { type: 'mousePressed', clickCount: 2 });

      // Check for the submit button
      const submitBtn = JobPortalInterface.checkElement(xpaths.submitBtn);

      // If the submit button exists, click it and recursively call the fillForm function
      if (submitBtn) {
        submitBtn.click();
        await fillForm();
      } else {
        // If the submit button does not exist, return
        return;
      }
    }

    /**
     * Automatically applies to a job by performing a series of checks and interactions on the webpage.
     *
     * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
     */
    async function autoApplyJob(jobDetails, tabId) {
      const key = `STARK_AUTO_APPLY_${tabId}`;
      const { [key]: state } = await chrome.storage.local.get(`STARK_AUTO_APPLY_${tabId}`);
      const stage = state && JSON.parse(state)?.job?.url === jobDetails?.url ? JSON.parse(state)?.stage : 'STAGE-1';
      switch (stage) {
        case 'STAGE-1':
          // Login Check
          const loginCheck = JobPortalInterface.checkElement(xpaths.login);
          if (!loginCheck) return { status: '', reason: 'Not Logged In', url: jobDetails?.url };

          // // Check if job is already applied
          const appliedButton = JobPortalInterface.checkElement(xpaths.applied);
          if (appliedButton) return { status: 'Already Applied', reason: null, url: jobDetails?.url };

          // Check if apply button is available
          const applyButton = JobPortalInterface.checkElement(xpaths.applyBtn);
          if (!applyButton) return { status: '', reason: 'Unable to find apply button', url: jobDetails?.url };
          await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-2', portal: 'Internshala', tabId }) });
          // Click Event for button
          applyButton.click();

        case 'STAGE-2':
          // Check for form container - ChatBot
          const proceedApplication = await JobPortalInterface.waitFor(xpaths.proceedBtn, 4000);

          // Continuously fill out the form until all questions are answered
          await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-3', portal: 'Internshala', tabId }) });
          if (proceedApplication) proceedApplication.click();

        case 'STAGE-3':
          await fillForm();
          const appliedStatus = await JobPortalInterface.waitFor(xpaths.appliedStatus, 6000);
          if (appliedStatus) {
            return { status: 'Applied', message: appliedStatus?.innerHTML, reason: null, url: jobDetails?.url };
          } else {
            return { status: '', reason: 'Unable to complete auto apply', url: jobDetails?.url };
          }
      }
    }
    // Call the autoApplyJob function and return its result
    return await autoApplyJob(job, tabId);
  }
}
