// FreshersWorld
import JobPortalInterface from './JobPortalInterface.js';

const flowXpaths = {
  login: "//div[@class='jobseeker-login display-block']",
  jobExpired: "//div[@class='job-apply-btn']//div[@class='job-expired']",
  appliedBtn: "//span[contains(text(),'You have already applied')] | //div[@class='job-apply-btn']//div[contains(@id,'already_applied_display') and @style='display: block;']",
  applyBtn: "//div[@class='job-apply-btn']//div[contains(@class, 'view-apply-container') and not(@style='display: none;')]//span[@class='view-apply-button']",
  loading: "//div[@class='job-apply-btn']//span[contains(@class,'please_wait') and @style='display: inline;']",
  loadingCompleted: "//div[@class='job-apply-btn']//span[contains(@class,'please_wait') and not(@style='display: inline;')]",
  dailog: "//div[@role='dialog' and @aria-labelledby='dataCollectionPopup']",
  skipDailogBtn: "//button[@id='skip-and-apply-btn']",
  profileBox: "//div[contains(@class,'content-left-side')]//div[contains(@class,'background-image')]",
};

export default class Freshersworld extends JobPortalInterface {
  getName() {
    return 'Freshersworld';
  }

  getDomain() {
    return 'www.freshersworld.com';
  }

  getJobsPath() {
    return '/jobs/jobsearch/';
  }

  getListingPath() {
    return '/jobs/';
  }

  getDescriptionSelector() {
    return '.job-desc';
  }

  async getJobDetails() {
    const jobDetails = {
      text: document.querySelector('.job-desc').textContent,
    };
    return jobDetails;
  }

  async apply(jobDetails, tabId) {
    /**
     * Automatically applies to a job by performing a series of checks and interactions on the webpage.
     *
     * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
     */
    const key = `STARK_AUTO_APPLY_${tabId}`;
    const { [key]: state } = await chrome.storage.local.get(`STARK_AUTO_APPLY_${tabId}`);
    const stage = state && JSON.parse(state)?.job?.url === jobDetails?.url ? JSON.parse(state)?.stage : 'STAGE-1';
    switch (stage) {
      case 'STAGE-1':
        // Login Check
        const loginButton = await JobPortalInterface.waitFor(flowXpaths.login);
        if (loginButton) return { status: '', reason: 'Not Logged In', url: jobDetails?.url };

        // Check for job expired
        const jobExpiredButton = JobPortalInterface.checkElement(flowXpaths.jobExpired);
        if (jobExpiredButton) return { status: '', reason: 'Job Expired', url: jobDetails?.url };

        // Check if job is already applied
        const appliedButton = JobPortalInterface.checkElement(flowXpaths.appliedBtn);
        if (appliedButton) return { status: 'Already Applied', reason: null, url: jobDetails?.url };

        // Check if apply button is available
        const applyButton = JobPortalInterface.checkElement(flowXpaths.applyBtn);
        if (!applyButton) return { status: '', reason: 'Unable to find apply button', url: jobDetails?.url };
        // Click event for apply button
        applyButton.click();

        // Store upcoming stage as this portal reloads on apply button click
        await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-2', portal: 'freshersworld', tabId }) });

        // Wait for loading text after apply button click
        await JobPortalInterface.waitFor(flowXpaths.loading);

        // Wait for loading complete
        await JobPortalInterface.waitFor(flowXpaths.loadingCompleted);

        // Check for dailog box if any
        const dailogBox = JobPortalInterface.checkElement(flowXpaths.dailog);
        if (dailogBox) {
          // Get skip button and click
          const skipBtn = JobPortalInterface.checkElement(flowXpaths.skipDailogBtn);
          skipBtn.click();
        }

      case 'STAGE-2':
        // Check profile box which gets after apply button click
        const profileBox = JobPortalInterface.checkElement(flowXpaths.profileBox);
        if (profileBox) {
          // Reload tab with original job url to check applied status
          await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-3', portal: 'freshersworld', tabId }) });
          window.location.href = jobDetails?.url;
        } else return { status: '', reason: 'Unable to complete auto apply', url: jobDetails?.url };

      case 'STAGE-3':
        // Check applied status
        const appliedBtn = await JobPortalInterface.waitFor(flowXpaths.appliedBtn);
        if (appliedBtn) {
          return { status: 'Applied', message: appliedBtn?.innerHTML, reason: null, url: jobDetails?.url };
        } else {
          return { status: '', reason: 'Unable to complete auto apply', url: jobDetails?.url };
        }
    }
  }
}
