import Naukri from './Naukri.js';
import Indeed from './Indeed.js';
import LinkedIn from './LinkedIn.js';
import Foundit from './FoundIt.js';
import TimesJobs from './TimesJobs.js';
import Shine from './Shine.js';
import Freshersworld from './Freshersworld.js';
import Internshala from './Internshala.js';
import Apna from './Apna.js';
import Glassdoor from './Glassdoor.js';
import Monster from './Monster.js';
import FlexJobs from './FlexJobs.js';
import CareerBuilder from './CareerBuilder.js'
import ZipRecruiter from './ZipRecruiter.js';
import Guru from './Guru.js'
import Ladders from './Ladders.js';
import Upwork from './Upwork.js';
import SimplyHired from './SimplyHired.js'
import Jora from './Jora.js'

class PortalManager {
  static getPortalInstance() {
    const hostname = window.location.hostname;
    if (hostname.includes('naukri.com')) {
      return new Naukri();
    } else if (hostname.includes('indeed.com')) {
      return new Indeed();
    } else if (hostname.includes('linkedin.com')) {
      return new LinkedIn();
    } else if (hostname.includes('foundit.in')) {
      return new Foundit();
    } else if (hostname.includes('timesjobs.com')) {
      return new TimesJobs();
    } else if (hostname.includes('shine.com')) {
      return new Shine();
    } else if (hostname.includes('freshersworld.com')) {
      return new Freshersworld();
    } else if (hostname.includes('internshala.com')) {
      return new Internshala();
    } else if (hostname.includes('apna.co')) {
      return new Apna();
    } else if (hostname.includes('glassdoor.co')) {
      return new Glassdoor();
    } else if (hostname.includes('monster.com')) {
      return new Monster();
    } else if (hostname.includes('flexjobs.com')) {
      return new FlexJobs();
    } else if (hostname.includes('careerbuilder.com')) {
      return new CareerBuilder();
    } else if (hostname.includes('ziprecruiter.co.uk')) {
      return new ZipRecruiter();
    } else if (hostname.includes('guru.com')) {
      return new Guru();
    } else if (hostname.includes('theladders.com')) {
      return new Ladders();
    } else if (hostname.includes('upwork.com')) {
      return new Upwork();
    } else if (hostname.includes('simplyhired.co.in') || hostname.includes('simplyhired.com')) {
      return new SimplyHired();
    } else if (hostname.includes('jora.com')) {
      return new Jora();
    }
    // throw new Error('Unsupported job portal');
    return
  }
}

export default PortalManager;
