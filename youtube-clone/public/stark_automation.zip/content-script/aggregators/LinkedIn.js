// Implementations for LinkedIn, Foundit, etc.
import JobPortalInterface from './JobPortalInterface.js';

const linkedInXpaths = {
  login: "//a[contains(@class,'btn-secondary-emphasis\\')]",
  companyWebsite: "//button[contains(@aria-label,'company website')]",
  jobExpired: "//div[contains(@class, 'jobs-details-top-card__apply-error')]",
  appliedBtn: "//a[@aria-label='Download your submitted resume']",
  applyBtn: "//button[contains(@class,'jobs-apply-button')]",
  formModal: "//div[@data-test-modal-id='easy-apply-modal']/div[@role='dialog']",
  applicationStatus: "//h3[contains(@class,'jpac-modal-header')]",
  submitBtn: "//button[contains(@aria-label,'Submit application')]",
  nextBtn: "//button[contains(@aria-label,'Continue to next step')]",
  continueBtn: "//button[contains(@class,'jobs-apply-button')]",
  reviewBtn: "//button[contains(@aria-label,'Review your application')]",
  input: "(//div[contains(@id,'error') and div[@role='alert']])[1]/preceding-sibling::div//input",
  dropdown: "(//div[contains(@id,'error') and div[@role='alert']])[1]/preceding-sibling::select",
  radio: "(//div[contains(@id,'error') and div[@role='alert']])[1]/preceding-sibling::select",
  uploadBtn: "//label[contains(@class,'_upload-button')]",
  resumeCard: "//div[contains(@class,'ui-attachment')]",
};
export default class LinkedIn extends JobPortalInterface {
  getName() {
    return 'LinkedIn';
  }

  getDomain() {
    return 'www.linkedin.com';
  }

  getJobsPath() {
    return '/jobs/search';
  }

  getListingPath() {
    return '/jobs/view';
  }

  getDescriptionSelector() {
    return '#job-details';
  }

  isFocusRequired() {
    return true;
  }

  async getJobDetails() {
    const jobDetails = {
      text: document.querySelector('#job-details')?.textContent,
    };
    return jobDetails;
  }

  async apply() {
    /**
     * Fills out a form by interacting with various elements such as radio buttons, checkboxes, and input fields.
     * Recursively calls itself if a chatbox container is detected after submission.
     */
    async function fillForm() {
      // Check for an input element preceding an error message and fill it with a random value between 1 and 10
      const inputElement = JobPortalInterface.checkElement(linkedInXpaths.input);
      if (inputElement) JobPortalInterface.fillInput(inputElement, Math.floor(Math.random() * 10) + 1, { attribute: 'value' });

      // Check for a dropdown element preceding an error message and select a random option
      const dropDownElement = JobPortalInterface.checkElement(linkedInXpaths.dropdown);
      if (dropDownElement) JobPortalInterface.selectRandomOption(linkedInXpaths.dropdown);

      // Check for a radio elements preceding an error message and click a random option
      const radioElement = JobPortalInterface.checkElement(linkedInXpaths.radio);
      if (radioElement) JobPortalInterface.clickRandomButton(linkedInXpaths.radio);

      // Call the function to handle LinkedIn specific form filling
      await fillLinkedInForm();
    }

    /**
     * Fills out a LinkedIn application form by interacting with various elements such as buttons.
     * Recursively calls itself if additional steps are detected.
     */
    async function fillLinkedInForm() {
      // Check for resume availability
      const uploadBtn = JobPortalInterface.checkElement(linkedInXpaths.uploadBtn);
      const resumeCard = JobPortalInterface.checkElement(linkedInXpaths.resumeCard);
      if (uploadBtn && !resumeCard) return { status: '', reason: 'Resume not available', url: job?.url };
      // Check for the submit button and click it if found
      const submitBtn = JobPortalInterface.checkElement(linkedInXpaths.submitBtn);
      if (submitBtn) return submitBtn.click();

      // Check for the next button, continue apply button, and review button, and click the appropriate one
      const nextBtn = JobPortalInterface.checkElement(linkedInXpaths.nextBtn);
      const continueApplyBtn = JobPortalInterface.checkElement(linkedInXpaths.continueBtn);
      const reviewBtn = JobPortalInterface.checkElement(linkedInXpaths.reviewBtn);
      if (!nextBtn && !continueApplyBtn && !reviewBtn) return;
      reviewBtn ? reviewBtn.click() : nextBtn ? nextBtn.click() : continueApplyBtn.click();

      // Wait for 1.5 seconds before continuing
      await JobPortalInterface.wait(1500);

      // Call the function to fill the form again
      await fillForm();
    }

    /**
     * Automatically applies to a job by performing a series of checks and interactions on the webpage.
     *
     * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
     */
    async function autoApplyJob() {
      // Check if the user is logged in
      const loginButton = JobPortalInterface.checkElement(linkedInXpaths.login);
      if (loginButton) return { status: '', reason: 'Not Logged In' };

      // Check for a company website button which indicates a manual application is needed
      const companyWebsiteButton = JobPortalInterface.checkElement(linkedInXpaths.companyWebsite);
      if (companyWebsiteButton) return { status: '', reason: 'Manually Apply on company website' };

      // Check if the job is expired
      const expiredJob = JobPortalInterface.checkElement(linkedInXpaths.jobExpired);
      if (expiredJob) return { status: 'The company is no longer accepting job applications', reason: null };

      // Check if the job is already applied
      const appliedButton = JobPortalInterface.checkElement(linkedInXpaths.appliedBtn);
      const applyButton = JobPortalInterface.checkElement(linkedInXpaths.applyBtn);
      if (!applyButton || appliedButton) return { status: 'Already Applied', reason: '' };

      // Click the apply button
      applyButton.click();

      // Check if the form container is present
      const formContainer = await JobPortalInterface.waitFor(linkedInXpaths.formModal, 6000);

      if (formContainer) {
        // Fill the form
        const error = await fillLinkedInForm();
        if (error) return error;

        // Check the application status
        const appliedStatus = await JobPortalInterface.waitFor(linkedInXpaths.applicationStatus, 6000);

        if (appliedStatus) {
          return { status: 'Applied', message: appliedStatus?.innerHTML, reason: null };
        } else {
          return { status: 'Failed', reason: 'Unable to complete auto apply' };
        }
      } else {
        // TODO - Need to work on job limit exceeded scenario once we get xpath
        return { status: '', reason: 'Job apply limit exceeded' };
      }
    }

    // Call the autoApplyJob function and return its result
    return await autoApplyJob();
  }
}
