// Implementations for Monster
import JobPortalInterface from './JobPortalInterface.js';
export default class Monster extends JobPortalInterface {
    getName() {
      return 'Monster';
    }
  
    getDomain() {
      return 'www.monster.com';
    }
  
    getJobsPath() {
      return '/jobs/search';
    }
  
    getListingPath() {
      return '/job-openings';
    }
  
    getDescriptionSelector() {
      return '[class*="descriptionstyles__DescriptionContainerInner"]';
    }
  
    async getJobDetails() {
      const jobDetails = {
        text: document.querySelector('[class*="descriptionstyles__DescriptionContainerInner"]').textContent
      };
      return jobDetails;
    }
  
    async apply(jobDetails, profileId) {
      const applicationData = {
        profile_id: profileId,
        job_id: jobDetails.id,
        application_message: 'I am very interested in this position and believe my skills and experience are a great fit.',
      };
  
      const response = await fetch('https://careerbuilder.com/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(applicationData),
      });
  
      if (response.ok) {
        return 'Application successful';
      } else {
        throw new Error('Application failed');
      }
    }
  }