// FoundIt
import JobPortalInterface from './JobPortalInterface.js';

const foundItXpaths = {
  login: "//button[contains(@class,'Register')]",
  appliedbtn: "//p[normalize-space()='You have successfully submitted your application.'] | //button[@class='applied']",
  applyBtn: "(//div[contains(@id,'jobHeader')]//*//*[normalize-space()='Quick Apply'])[2]",
  jobAnchorTag: "(//div[contains(@id,'jobHeader')]//*//*[normalize-space()='Quick Apply'])[1]",
  appliedStatus: "//div[contains(@class,'success-toast')]",
};
export default class Foundit extends JobPortalInterface {
  getName() {
    return 'Foundit';
  }

  getDomain() {
    return 'www.foundit.in';
  }

  getJobsPath() {
    return '/srp/results';
  }

  getListingPath() {
    return '/job-listing';
  }

  getDescriptionSelector() {
    return '#jobDescription';
  }

  async getJobDetails() {
    const jobDetails = {
      text: document.querySelector(this.getDescriptionSelector())?.textContent,
    };
    return jobDetails;
  }

  async apply(job, tabId) {
    /**
     * Automatically applies to a job by performing a series of checks and interactions on the webpage.
     *
     * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
     */
    async function autoApplyJob(jobDetails, tabId) {
      let appliedStatus;
      const key = `STARK_AUTO_APPLY_${tabId}`;
      const { [key]: state } = await chrome.storage.local.get(`STARK_AUTO_APPLY_${tabId}`);
      const stage = state && JSON.parse(state)?.job?.url === jobDetails?.url ? JSON.parse(state)?.stage : 'STAGE-1';
      switch (stage) {
        case 'STAGE-1':
          // Login Check
          const loginButton = JobPortalInterface.checkElement(foundItXpaths.login);
          if (loginButton) return { status: '', reason: 'Not Logged In', url: jobDetails?.url };

          // Check if job is already applied
          const appliedButton = JobPortalInterface.checkElement(foundItXpaths.appliedbtn);
          if (appliedButton) return { status: 'Already Applied', reason: null, url: jobDetails?.url };

          // Check if apply button is available
          const applyButton = JobPortalInterface.checkElement(foundItXpaths.applyBtn);
          if (!applyButton) return { status: '', reason: 'Manually Apply on company website', url: jobDetails?.url };
          await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-2', portal: 'Foundit', tabId }) });
          const jobLinkElement = JobPortalInterface.checkElement(foundItXpaths.jobAnchorTag);
          jobLinkElement.target = '_self';
          // Click Event for button
          applyButton.click();

        case 'STAGE-2':
          // Check for applied status
          appliedStatus = JobPortalInterface.waitFor(foundItXpaths.appliedStatus,6000);
          if (appliedStatus) {
            return { status: 'Applied', message: appliedStatus?.innerHTML, reason: null, url: jobDetails?.url };
          } else {
            return { status: '', reason: 'Unable to complete auto apply', url: jobDetails?.url };
          }
      }
    }
    // Call the autoApplyJob function and return its result
    return await autoApplyJob(job, tabId);
  }
}
