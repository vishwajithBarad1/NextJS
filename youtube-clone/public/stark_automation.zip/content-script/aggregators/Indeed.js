// Similar implementations for other portals
import JobPortalInterface from './JobPortalInterface.js';

const indeedXpaths = {
  login: "//nav[@id='gnav-main-container']//a[text()='Sign in']",
  companyWebsite: '//button[contains(@aria-label,"Apply now") and @href]',
  expiredJob: '//div[@role="group"]/div/div/text()',
  applied: '//div//button[contains(@aria-label,"Applied")] | //h1[normalize-space()="Your application has been submitted!"]',
  applyBtn: '//button[contains(@aria-label,"Apply now") and not(@href)]',
  form: "//section[contains(@class,'ia-Navigation')]",
  applied: '//div[@class="ia-PostApply-header"]//h1',
  firstName: "//input[contains(@name,'firstName')]",
  lastName: "//input[contains(@name,'lastName')]",
  phone: "//input[contains(@name,'phoneNumber')]",
  resume: "//label[@data-testid='FileResumeCard-label']//span[@data-testid='FileResumeCardHeader-title']",
  formFields:{
    number:"(//div[contains(@id, 'errorTextId')])[1]/preceding-sibling::span/input[@type='number']",
    text:"(//div[contains(@id, 'errorTextId')])[1]/preceding-sibling::span/input[@type='text']",
    textArea:"(//div[contains(@id, 'errorTextId')])[1]/preceding-sibling::span/textarea",
    button:"(//div[contains(@id, 'errorTextId')])[1]/preceding-sibling::label/input",

  },
  submitBtn:"//div[contains(@class, 'ia-BasePage-footer')]//button"
};
export default class Indeed extends JobPortalInterface {
  getName() {
    return 'Indeed';
  }

  getDomain() {
    return 'in.indeed.com';
  }

  getJobsPath() {
    return '/jobs';
  }

  getListingPath() {
    return '/viewjob';
  }

  getDescriptionSelector() {
    return '#jobDescriptionText';
  }

  isFocusRequired() {
    return true;
  }

  async getJobDetails() {
    const jobDetails = {
      text: document.querySelector('#jobDescriptionText')?.textContent,
    };
    return jobDetails;
  }

 /**
 * Automatically applies to a job on Indeed by filling out forms and interacting with webpage elements.
 *
 * @param {Object} job - The job details to apply to.
 * @param {number} tabId - The ID of the current browser tab.
 * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
 */
  async apply(job, tabId) {
  const currentTabId = tabId;
  /**
   * Submits the current form section by clicking the submit button and waiting for 2 seconds.
   *
   * @returns {Promise<HTMLElement|null>} - A promise that resolves to the submit button element, or null if not found.
   */
  async function submitFormSection() {
      const submitBtn = JobPortalInterface.checkElement(indeedXpaths.submitBtn);
      submitBtn && submitBtn.click();
      await JobPortalInterface.wait(2000);
      return submitBtn;
  }

  /**
   * Fills in the basic details (first name, last name, phone) in the form.
   * If the details are not filled in, it retries until successful.
   */
  async function fillBasicDetails() {
      const firstName = JobPortalInterface.checkElement(indeedXpaths.firstName);
      if (firstName && !firstName?.value) await JobPortalInterface.debuggerFillInput(currentTabId, indeedXpaths.firstName, 'John', { type: 'mousePressed' ,inputType : 'keyDown', clickCount: 2 });
      if (firstName && !firstName?.value) await fillBasicDetails();

      const lastName = JobPortalInterface.checkElement(indeedXpaths.lastName);
      if (lastName && !lastName?.value) await JobPortalInterface.debuggerFillInput(currentTabId, indeedXpaths.lastName, 'Doe', { type: 'mousePressed', inputType : 'keyDown',clickCount: 2 });
      if (lastName && !lastName?.value) await fillBasicDetails();

      const phone = JobPortalInterface.checkElement(indeedXpaths.phone);
      if (phone && !phone?.value) await JobPortalInterface.debuggerFillInput(currentTabId, indeedXpaths.phone, '2244556633', { type: 'mousePressed', inputType : 'keyDown',clickCount: 2 });
      if (phone && !phone?.value) await fillBasicDetails();
  }

  /**
 * Fills out a form by interacting with various elements such as resume upload, number input, text input, text area, and buttons.
 * Recursively calls itself if a chatbox container is detected after submission.
 */
async function fillForm() {
  // Check and click the resume upload button if it exists
  const resume = JobPortalInterface.checkElement(indeedXpaths.resume);
  if(resume && resume.innerText === "Upload a CV") return {status: '', reason: 'Resume not available', url: job?.url}
  if (resume) {
      resume.click();
      await JobPortalInterface.wait(2000);
  }

  // Check and fill the number input field if it exists
  const numberInput = JobPortalInterface.checkElement(indeedXpaths.formFields.number);
  if (numberInput) await JobPortalInterface.debuggerFillInput(currentTabId, indeedXpaths.formFields.number, '5', { type: 'mousePressed',inputType : 'keyDown', clickCount: 2 });

  // Check and fill the text input field if it exists
  const textInput = JobPortalInterface.checkElement(indeedXpaths.formFields.text);
  if (textInput) await JobPortalInterface.debuggerFillInput(currentTabId, indeedXpaths.formFields.text, 'N/A', { type: 'mousePressed',inputType : 'keyDown', clickCount: 2 });

  // Check and fill the text area field if it exists
  const textAreaInput = JobPortalInterface.checkElement(indeedXpaths.formFields.textArea);
  if (textAreaInput) await JobPortalInterface.debuggerclickButton(currentTabId, indeedXpaths.formFields.textArea, 'N/A', { type: 'mousePressed', clickCount: 2 });

  // Check and click the button input if it exists
  const buttonInput = JobPortalInterface.checkElement(indeedXpaths.formFields.button);
  if (buttonInput) {
      await JobPortalInterface.debuggerclickButton(currentTabId, indeedXpaths.formFields.button, 'mousePressed', 2);
      await JobPortalInterface.debuggerclickButton(currentTabId, indeedXpaths.formFields.button, 'mouseReleased', 2);
  }

  // Submit the form section and wait for 2 seconds
  const submitBtn = await submitFormSection();
  await JobPortalInterface.wait(2000);

  // If the submit button indicates the end of the form, return; otherwise, recursively call fillForm to continue
  if (submitBtn && submitBtn.innerText?.toLowerCase()?.includes('submit')) return;
  else await fillForm();
}


  /**
   * Automatically applies to a job by performing a series of checks and interactions on the webpage.
   *
   * @param {Object} jobDetails - The job details to apply to.
   * @param {number} tabId - The ID of the current browser tab.
   * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
   */
  async function autoApplyJob(jobDetails, tabId) {
      let appliedStatus;
      const key = `STARK_AUTO_APPLY_${tabId}`;
      const { [key]: state } = await chrome.storage.local.get(`STARK_AUTO_APPLY_${tabId}`);
      const stage = state && JSON.parse(state)?.job?.url === jobDetails?.url ? JSON.parse(state)?.stage : 'STAGE-1';

      switch (stage) {
          case 'STAGE-1':
              // Login Check
              const loginButton = JobPortalInterface.checkElement(indeedXpaths.login);
              if (loginButton) return { status: '', reason: 'Not Logged In', url: jobDetails?.url };

              // Check for company website
              const companyWebsiteButton = JobPortalInterface.checkElement(indeedXpaths.companyWebsite);
              if (companyWebsiteButton) return { status: '', reason: 'Manually Apply on company website', url: jobDetails?.url };

              // Check if Job is Expired
              const expiredJob = JobPortalInterface.checkElement(indeedXpaths.expiredJob);
              if (expiredJob) return { status: '', reason: 'Job expired', url: jobDetails?.url };

              // Check if job is already applied
              const appliedButton = JobPortalInterface.checkElement(indeedXpaths.applied);
              if (appliedButton) return { status: 'Already Applied', reason: null, url: jobDetails?.url };

              // Check if apply button is available
              const applyButton = JobPortalInterface.checkElement(indeedXpaths.applyBtn);
              if (!applyButton) return { status: '', reason: 'Unable to find apply button', url: jobDetails?.url };
              await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-2', portal: 'Indeed', tabId }) });
              await JobPortalInterface.wait(2000);
              // Click Event for button
              applyButton.click();

          case 'STAGE-2':
              // Wait for 4 seconds for the chatbot to load
              await JobPortalInterface.wait(4000);
              // Check for form container - ChatBot
              const formFillContainer = JobPortalInterface.checkElement(indeedXpaths.form);

              await JobPortalInterface.wait(2000);
              // Continuously fill out the form until all questions are answered
              await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-3', portal: 'Indeed', tabId }) });
              if (formFillContainer) {
                  await fillBasicDetails();
                  await submitFormSection();
                  const error = await fillForm();
                  if(error) return error
              }

          case 'STAGE-3':
              // Wait for 2 seconds
              await JobPortalInterface.wait(2000);
              appliedStatus = JobPortalInterface.checkElement(indeedXpaths.applied);
              if (appliedStatus) {
                  return { status: 'Applied', message: appliedStatus?.innerHTML, reason: null, url: jobDetails?.url };
              } else {
                  return { status: '', reason: 'Unable to complete auto apply', url: jobDetails?.url };
              }
      }
  }

  // Call the autoApplyJob function and return its result
  return await autoApplyJob(job, tabId);
}

}
