// TimesJobs
import JobPortalInterface from './JobPortalInterface.js';

const flowXpaths = {
  login: "//li[@class='login-reg']//a[text()='Login']",
  companyWebsite: "//div[@class='jd-header wht-shd-bx']//span[@class='tooltipped']",
  appliedBtn: "//div[@class='ubility-lhs']//div[@class='msg success']",
  applyBtn: "//div[contains(@class,'jd-header wht-shd-bx')]//a[contains(@class,'waves-effect waves-light btn')]",
  applicationStatus: "//div[@class='succ-apply-msg']//h3[contains(text(), 'Thank you')] | //div[@class='succ-apply-msg']//h3[contains(text(), 'Congratulations')]",
};

export default class TimesJobs extends JobPortalInterface {
  getName() {
    return 'TimesJobs';
  }

  getDomain() {
    return 'www.timesjobs.com';
  }

  getJobsPath() {
    return '/candidate/job-search';
  }

  getListingPath() {
    return '/job-detail';
  }

  getDescriptionSelector() {
    return '.jd-sec';
  }

  async getJobDetails() {
    const jobDetails = {
      text: document.querySelector('.jd-sec')?.innerText,
    };
    return jobDetails;
  }

  async apply(jobDetails, tabId) {
    /**
     * Automatically applies to a job by performing a series of checks and interactions on the webpage.
     *
     * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
     */
    const key = `STARK_AUTO_APPLY_${tabId}`;
    const { [key]: state } = await chrome.storage.local.get(`STARK_AUTO_APPLY_${tabId}`);
    const stage = state && JSON.parse(state)?.job?.url === jobDetails?.url ? JSON.parse(state)?.stage : 'STAGE-1';
    switch (stage) {
      case 'STAGE-1':
        // Login Check
        const loginButton = await JobPortalInterface.waitFor(flowXpaths.login, 3000);
        if (loginButton) return { status: '', reason: 'Not Logged In', url: jobDetails?.url };

        // Check for company website redirect button
        const companyWebsiteButton = JobPortalInterface.checkElement(flowXpaths.companyWebsite);
        if (companyWebsiteButton) return { status: '', reason: 'Manually Apply on company website', url: jobDetails?.url };

        // Check if job is already applied
        const appliedButton = JobPortalInterface.checkElement(flowXpaths.appliedBtn);
        if (appliedButton) return { status: 'Already Applied', reason: null, url: jobDetails?.url };

        // Check if apply button is available
        const applyButton = JobPortalInterface.checkElement(flowXpaths.applyBtn);
        if (!applyButton) return { status: '', reason: 'Unable to find apply button', url: jobDetails?.url };

        // Click event for apply button
        applyButton.click();

        // Store upcoming stage as this portal reloads on apply button click
        await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-2', portal: 'freshersworld', tabId }) });

      case 'STAGE-2':
        // Check application status
        const applicationStatus = JobPortalInterface.waitFor(flowXpaths.applicationStatus);
        if (applicationStatus) return { status: 'Applied', message: appliedBtn?.innerHTML, reason: null, url: jobDetails?.url };
        else return { status: '', reason: 'Unable to complete auto apply', url: jobDetails?.url };
    }
  }
}
