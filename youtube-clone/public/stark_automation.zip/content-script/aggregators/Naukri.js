// Naukri.js
import JobPortalInterface from './JobPortalInterface.js';

const naukriXpaths = {
  login: "//a[contains(@title,'Jobseeker Login')]",
  companyWebsite: "//button[contains(@id,'company-site-button')]",
  appliedBtn: "//span[contains(@id,'already-applied')]",
  applyBtn: "//button[contains(@id,'apply-button')]",
  chatBox: "//div[contains(@class,'chatbot_Drawer')]",
  appliedStatus: "//span[contains(@class,'apply-message')]",
  radioInputs: "//div[contains(@id,'SingleSelectRadioButton')]",
  radioInput: "//input[@type='radio' and contains(@class, 'ssrc__radio')]",
  checkBoxInputs: "//div[contains(@id,'MultiSelectCheckbox')]",
  checkBoxInput: "//input[@type='checkbox' and contains(@class, 'mcc__checkbox')]",
  multiTagsInput: "//div[contains(@id,'chips_container')]",
  multiTagInput: "//div[contains(@class, 'chipsContainer')]//div[contains(@class, 'chatbot_Chip')]",
  input: "//div[contains(@id,'userInput__')]",
  submitBtn: "//div[contains(@id,'sendMsg__')]",
};
export default class Naukri extends JobPortalInterface {
  getName() {
    return 'Naukri';
  }

  getDomain() {
    return 'www.naukri.com';
  }

  getJobsPath() {
    return '-jobs';
  }

  getListingPath() {
    return '/job-listings-';
  }

  getDescriptionSelector() {
    return '.styles_job-desc-container__txpYf';
  }

  async getJobDetails() {
    const jobDetails = {
      text: document.querySelector('.styles_job-desc-container__txpYf')?.textContent,
    };
    return jobDetails;
  }

  async apply(job, tabId) {
    /**
     * Fills out a form by interacting with various elements such as radio buttons, checkboxes, and input fields.
     * Recursively calls itself if a chatbox container is detected after submission.
     */
    async function fillForm() {
      let chatBoxContainer;
      let checkBoxButtons;
      let radioButtons;
      let multiTagButtons;
      // Verify if the current question's answer requires selecting a radio button
      const radioElement = JobPortalInterface.checkElement(naukriXpaths.radioInputs);
      if (radioElement) radioButtons = await JobPortalInterface.waitFor(naukriXpaths.radioInput, 4000);
      if (radioButtons) JobPortalInterface.clickRandomButton(naukriXpaths.radioInput);

      // Verify if the current question's answer requires selecting a Multi Select CheckBox
      const checkBoxElement = JobPortalInterface.checkElement(naukriXpaths.checkBoxInputs);
      if (checkBoxElement) checkBoxButtons = await JobPortalInterface.waitFor(naukriXpaths.checkBoxInput, 4000);
      if (checkBoxButtons) JobPortalInterface.clickRandomButton(naukriXpaths.checkBoxInput);

      // Verify if the current question's answer requires clicking on a Tag
      const multiTags = JobPortalInterface.checkElement(naukriXpaths.multiTagsInput);
      if (multiTags) multiTagButtons = await JobPortalInterface.waitFor(naukriXpaths.multiTagInput, 4000);
      if (multiTagButtons) JobPortalInterface.clickRandomButton(naukriXpaths.multiTagInput);

      // Verify if the current question's answer requires entering an input
      const inputElement = JobPortalInterface.checkElement(naukriXpaths.input);
      if (inputElement) JobPortalInterface.fillInput(inputElement, 'NA', {});

      // Submit the answer
      const submitBtn = JobPortalInterface.checkElement(naukriXpaths.submitBtn);
      submitBtn && submitBtn.click();
      // Check for form container - ChatBot
      chatBoxContainer = await JobPortalInterface.waitFor(naukriXpaths.chatBox, 4000);

      await JobPortalInterface.wait(2000);
      if (chatBoxContainer) await fillForm();
    }

    /**
     * Automatically applies to a job by performing a series of checks and interactions on the webpage.
     *
     * @returns {Promise<Object>} - A promise that resolves to an object containing the status and reason/message of the application process.
     */
    async function autoApplyJob(jobDetails, tabId) {
      let chatBoxContainer;
      let appliedStatus;
      const key = `STARK_AUTO_APPLY_${tabId}`;
      const { [key]: state } = await chrome.storage.local.get(`STARK_AUTO_APPLY_${tabId}`);
      const stage = state && JSON.parse(state)?.job?.url === jobDetails?.url ? JSON.parse(state)?.stage : 'STAGE-1';
      switch (stage) {
        case 'STAGE-1':
          // Login Check
          const loginButton = JobPortalInterface.checkElement(naukriXpaths.login);
          if (loginButton) return { status: '', reason: 'Not Logged In', url: jobDetails?.url };

          // Check for company website
          const companyWebsiteButton = JobPortalInterface.checkElement(naukriXpaths.companyWebsite);
          if (companyWebsiteButton) return { status: '', reason: 'Manually Apply on company website', url: jobDetails?.url };

          // Check if job is already applied
          const appliedButton = JobPortalInterface.checkElement(naukriXpaths.appliedBtn);
          if (appliedButton) return { status: 'Already Applied', reason: null, url: jobDetails?.url };

          // Check if apply button is available
          const applyButton = JobPortalInterface.checkElement(naukriXpaths.applyBtn);
          if (!applyButton) return { status: '', reason: 'Unable to find apply button', url: jobDetails?.url };
          await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-3', portal: 'naukri', tabId }) });
          // Click Event for button
          applyButton.click();

        case 'STAGE-2':
          // Check for form container - ChatBot
          chatBoxContainer = await JobPortalInterface.waitFor(naukriXpaths.chatBox, 4000);

          // Continuously fill out the form until all questions are answered
          await chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: JSON.stringify({ job: jobDetails, stage: 'STAGE-3', portal: 'naukri', tabId }) });
          if (chatBoxContainer) await fillForm();

        case 'STAGE-3':
          // Wait for 2 seconds
          appliedStatus = await JobPortalInterface.waitFor(naukriXpaths.appliedStatus, 6000);
          if (appliedStatus) {
            return { status: 'Applied', message: appliedStatus?.innerHTML, reason: null, url: jobDetails?.url };
          } else {
            return { status: '', reason: 'Unable to complete auto apply', url: jobDetails?.url };
          }
      }
    }
    // Call the autoApplyJob function and return its result
    return await autoApplyJob(job, tabId);
  }
}
