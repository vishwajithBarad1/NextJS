// FlexJobs.js
import JobPortalInterface from './JobPortalInterface.js';
export default class FlexJobs extends JobPortalInterface {
    getName() {
      return 'FlexJobs';
    }
  
    getDomain() {
      return 'www.flexjobs.com';
    }
  
    getJobsPath() {
      return '/search';
    }
  
    getListingPath() {
      return '/publicjobs';
    }
  
    getDescriptionSelector() {
      return '[class*="JobDetails_jobDescription"]';
    }
  
    async getJobDetails() {
      const jobDetails = {
        id: document.querySelector('.job-id').textContent,
        title: document.querySelector('.job-title').textContent,
        company: document.querySelector('.company-name').textContent,
        location: document.querySelector('.job-location').textContent,
      };
      return jobDetails;
    }
  
    async apply(jobDetails, profileId) {
      const applicationData = {
        profile_id: profileId,
        job_id: jobDetails.id,
        application_message: 'I am very interested in this position and believe my skills and experience are a great fit.',
      };
  
      const response = await fetch('https://glassdoor.example.com/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(applicationData),
      });
  
      if (response.ok) {
        return 'Application successful';
      } else {
        throw new Error('Application failed');
      }
    }
  }
  
  