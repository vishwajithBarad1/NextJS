// Upwork.js
import JobPortalInterface from './JobPortalInterface.js';
export default class Upwork extends JobPortalInterface {
    getName() {
      return 'Upwork';
    }
  
    getDomain() {
      return 'www.upwork.com/';
    }
  
    getJobsPath() {
      return '/search/jobs/';
    }
  
    getListingPath() {
      return '/freelance-jobs';
    }
  
    getDescriptionSelector() {
      return '[data-test="Description"] > p';
    }
  
    async getJobDetails() {
      const jobDetails = {
        text: document.querySelector('[data-test="Description"] > p').textContent,
      };
      return jobDetails;
    }
  
    async apply(jobDetails, profileId) {
      const applicationData = {
        profile_id: profileId,
        job_id: jobDetails.id,
        application_message: 'I am very interested in this position and believe my skills and experience are a great fit.',
      };
  
      const response = await fetch('https://example.com/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(applicationData),
      });
  
      if (response.ok) {
        return 'Application successful';
      } else {
        throw new Error('Application failed');
      }
    }
  }
  
  