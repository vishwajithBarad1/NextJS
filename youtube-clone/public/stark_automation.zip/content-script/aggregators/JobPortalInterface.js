export default class JobPortalInterface {
  constructor() {
    this.sendPageInfoToBackgroundScript = this.sendPageInfoToBackgroundScript.bind(this);
    this.generateUUID = this.generateUUID.bind(this);
    this.displaySuccessMessage = this.displaySuccessMessage.bind(this);
    this.displayErrorMessage = this.displayErrorMessage.bind(this);
  }

  getName() {
    return '';
  }

  getDomain() {
    throw new Error('getDomain() must be implemented.');
  }

  getJobsPath() {
    throw new Error('getJobsPath() must be implemented.');
  }

  getListingPath() {
    throw new Error('getListingPath() must be implemented.');
  }

  getDescriptionSelector() {
    throw new Error('getDescriptionSelector() must be implemented.');
  }

  async getJobDetails() {
    throw new Error('getJobDetails() must be implemented.');
  }
  //  Focus required will be false by default , we can enable it for the required portal
  isFocusRequired() {
    return false;
  }

  async apply(jobDetails, profileId) {
    throw new Error('apply() must be implemented.');
  }

  async getScore(profile) {
    const accessToken = await this.getAccessToken();
    if (!accessToken) {
      const messageBox = this.displayMessageBox(`Stark.ai can fetch the AI match score for this job against your profiles. <br/><strong>Please signup or login to your account.</strong>`);
      messageBox.style.backgroundColor = '#ffcc00';
      messageBox.style.color = '#000000';
      return;
    }

    const jobDescriptionText = profile.descriptionText;

    return fetch('https://v2.stark.ai/ai/relevance/user', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        job_description_text: jobDescriptionText,
        access_token: accessToken, // Include the access token in the request body
      }),
      credentials: 'include',
    })
      .then(response => response.json())
      .then(data => {
        if (data && data.relevance_scores) {
          let message = 'AI relevance scores:\n';
          data.relevance_scores.forEach(score => {
            message += `Resume: ${score.fileName}, Score: ${score.relevance_score}\n`;
          });
          this.displayMessageBox(message);
        } else {
          this.displayMessageBox('Failed to fetch AI relevance scores.');
        }
      })
      .catch(error => {
        console.error('Error fetching AI relevance scores:', error);
        this.displayMessageBox('Error fetching AI relevance scores.');
      });
  }

  async getAccessToken() {
    return new Promise(resolve => {
      chrome.runtime.sendMessage({ action: 'get_stark_access_token' }, response => {
        resolve(response.accessToken);
      });
    });
  }

  async waitForElement(selector, timeout = 5000) {
    return new Promise((resolve, reject) => {
      const interval = 100; // Check every 100ms
      const maxAttempts = timeout / interval;
      let attempts = 0;

      const checkForElement = () => {
        const element = document.querySelector(selector);
        if (element) {
          resolve(element);
        } else if (attempts >= maxAttempts) {
          reject(new Error(`Element with selector "${selector}" not found within ${timeout}ms`));
        } else {
          attempts += 1;
          setTimeout(checkForElement, interval);
        }
      };

      checkForElement();
    });
  }
  // Wait for an element specified by XPath to load within a given time frame
  static async waitFor(xpath, timeout = 5000) {
    return new Promise((resolve, reject) => {
      const interval = 500; // Check for the element every 100ms
      const maxAttempts = timeout / interval;
      let attempts = 0;

      // Function to check for the presence of the element
      const checkForElement = xpath => {
        const element = JobPortalInterface.checkElement(xpath);
        if (element) {
          // If the element is found, resolve the promise with the element
          resolve(element);
        } else if (attempts >= maxAttempts) {
          // If the maximum attempts limit is reached without finding the element, reject the promise
          resolve(null);
        } else {
          // If the element is not found yet and attempts are within the limit, increment attempts and check again after a short delay
          attempts += 1;
          setTimeout(() => checkForElement(xpath), interval);
        }
      };

      // Initial call to start checking for the element
      checkForElement(xpath);
    });
  }

  /**
   * Checks if an element exists in the document based on the provided XPath.
   *
   * @param {string} xpath - The XPath expression to locate the element.
   * @returns {Element|null} - The first matching element or null if no match is found.
   */
  static checkElement(xpath) {
    return document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null)?.singleNodeValue;
  }

  /**
   * Creates a promise that resolves after a specified amount of time.
   *
   * @param {number} time - The amount of time to wait in milliseconds.
   * @returns {Promise<void>} - A promise that resolves after the specified time.
   */
  static wait(time) {
    return new Promise(resolve => setTimeout(resolve, time));
  }

  static dispatchCustomEvent(element, eventType) {
    // Dispatch event to simulate change
    const event = new Event(eventType, {
      bubbles: true,
      cancelable: true,
    });
    element.dispatchEvent(event);
  }

  /**
   * Clicks a random button found using the provided XPath expression.
   *
   * @param {string} xpath - The XPath expression to locate the buttons.
   */
  static clickRandomButton(xpath) {
    const iterator = document.evaluate(xpath, document, null, XPathResult.UNORDERED_NODE_ITERATOR_TYPE, null);
    const radioButtons = [];
    let node = iterator.iterateNext();

    while (node) {
      radioButtons.push(node);
      node = iterator.iterateNext();
    }

    // Get a random index
    const randomIndex = Math.floor(Math.random() * radioButtons.length);

    // Click the random radio button
    radioButtons[randomIndex].click();
  }

  /**
   * Fills an input element (e.g., a contenteditable div) with the text 'N/A' and simulates a user typing.
   *
   * @param {Element} inputElement - The input element to fill.
   */
  static fillInput(inputElement, value = 'N/A', { attribute = 'innerText' }) {
    // Set the contenteditable div to "N/A"
    inputElement[attribute] = value;
    // Dispatch input event to simulate user typing
    JobPortalInterface.dispatchCustomEvent(inputElement, 'input');
  }

  /**
   * Selects a random option found using the provided XPath expression.
   *
   * @param {string} xpath - The XPath expression to locate the buttons.
   */

  static selectRandomOption(xpath) {
    const iterator = document.evaluate(xpath, document, null, XPathResult.UNORDERED_NODE_ITERATOR_TYPE, null);
    const selectElement = iterator.iterateNext();

    if (selectElement && selectElement.tagName === 'SELECT') {
      const options = selectElement.options;

      // Get a random index, excluding the first option (index 0)
      const randomIndex = Math.floor(Math.random() * (options.length - 1)) + 1;

      // Set the random option as the selected option
      selectElement.selectedIndex = randomIndex;

      const element = JobPortalInterface.checkElement(xpath);
      // Dispatch change event for dropdown
      JobPortalInterface.dispatchCustomEvent(element, 'change');
    } else {
      console.error('No <select> element found with the provided XPath.');
    }
  }

  /**
   * Static method to get the center location of an element on the page.
   * @param {string} xpath - The XPath of the element to locate.
   * @returns {Object} An object containing the 'left' and 'top' coordinates of the element's center.
   */
  static getInputLocation(xpath) {
    // Check if the element exists on the page using the provided XPath.
    const element = JobPortalInterface.checkElement(xpath);
    // Get the bounding rectangle of the element.
    const rect = element.getBoundingClientRect();

    // Calculate the center point of the element.
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    // Return the center coordinates of the element.
    return { left: centerX, top: centerY };
  }

  /**
   * Static method to fill an input box one character at a time.
   * @param {number} tabId - The ID of the tab where the input box is located.
   * @param {string} text - The text to fill into the input box.
   * @param {string} [type='keyDown'] - The type of key event to dispatch.
   */
  static async fillInputBox(tabId, text, type = 'keyDown') {
    // Send a message to dispatch a key event with the first character of the text.
    await chrome.runtime.sendMessage({
      action: 'debugger_command',
      tabId,
      event_name: 'Input.dispatchKeyEvent',
      data: {
        type,
        text: text?.[0],
      },
    });
    // If there is more text to send, set a timeout to call the function again with the remaining text.
    if (text.length) {
      // Set a timeout to send remaining string
      await JobPortalInterface.fillInputBox(tabId, text.substring(1), type);
    } else {
      return;
    }
  }

  /**
   * Static method to fill an input box by first clicking it and then sending the input text.
   * @param {number} tabId - The ID of the tab where the input box is located.
   * @param {string} xpath - The XPath of the input box to fill.
   * @param {string} value - The text to fill into the input box.
   * @param {Object} [clickOptions={ type: 'mousePressed', inputType: 'keyDown', clickCount: 2 }] - The options for clicking and inputting text.
   */
  static async debuggerFillInput(tabId, xpath, value, clickOptions = { type: 'mousePressed', inputType: 'keyDown', clickCount: 2 }) {
    // Click the button to focus on the input box.
    await JobPortalInterface.debuggerclickButton(tabId, xpath, clickOptions.type, clickOptions.clickCount);

    // If there is text to input, start filling the input box.
    if (value.length) await JobPortalInterface.fillInputBox(tabId, value, clickOptions.inputType);
  }

  /**
   * Static method to simulate a button click at the center of an element.
   * @param {number} tabId - The ID of the tab where the element is located.
   * @param {string} xpath - The XPath of the element to click.
   * @param {string} [type='mousePressed'] - The type of mouse event to dispatch.
   * @param {number} [clickCount=1] - The number of mouse clicks.
   * @returns {Promise} The promise resolving the result of the click action.
   */
  static async debuggerclickButton(tabId, xpath, type = 'mousePressed', clickCount = 1) {
    // Get the center location of the element.
    const elementPosition = JobPortalInterface.getInputLocation(xpath);

    // Send a message to dispatch a mouse event at the center location of the element.
    return await chrome.runtime.sendMessage({
      action: 'debugger_command',
      tabId,
      event_name: 'Input.dispatchMouseEvent',
      data: {
        type,
        button: 'left',
        x: elementPosition.left,
        y: elementPosition.top,
        clickCount,
      },
    });
  }

  async init() {
    // Get profile details from chrome storage
    const { profile_details: profileDetails } = await chrome.storage.local.get('profile_details');
    const portal = this;
    const portalName = portal.getName();
    if (portalName === 'LinkedIn' || portalName === 'Indeed' || portalName === 'Freshersworld' || portalName === 'Internshala') {
      const { tabId } = await chrome.runtime.sendMessage({ action: 'get_tabId' });
      const debug = await chrome.runtime.sendMessage({ action: 'active_debugger', tabId });
      !debug.active && (await chrome.runtime.sendMessage({ action: 'attach_debugger', tabId }));
      // Send message to debugger for dispatching mouse hover event on the tab to get user details for Freshersworld
      portalName === 'Freshersworld' ? chrome.runtime.sendMessage({ action: 'debugger_command', event_name: 'Input.dispatchMouseEvent', tabId, data: { type: 'mouseMoved', x: 100, y: 200, timestamp: Date.now() } }) : await chrome.runtime.sendMessage({ action: 'debugger_command', event_name: 'Emulation.setFocusEmulationEnabled', tabId, data: { enabled: true } });
    }
    if (window.location.pathname.includes(portal.getJobsPath())) {
      // Define the display message with the initial text
      let displayMessage = `Stark.ai can auto apply to these jobs.`;

      // Check if profileDetails is available and has at least one profile
      if (profileDetails && profileDetails.length > 0) {
        // Create a select element for profile selection
        const profileSelect = document.createElement('select');
        profileSelect.className = 'stark-add-search';
        profileSelect.innerHTML = '<option value="" disabled selected>Select a profile</option>';

        // Loop through each profile and create an option element for it
        profileDetails.forEach(profile => {
          const option = document.createElement('option');
          option.value = profile.fileName;
          option.textContent = profile.fileName;
          profileSelect.appendChild(option);
        });

        // Append the profile select HTML to the display message
        displayMessage += ` ${profileSelect.outerHTML} to add this search.`;
      } else {
        // Create a link element for adding the search if no profiles are available
        const link = document.createElement('a');
        link.href = '#';
        link.className = 'stark-add-search';
        link.textContent = 'Click here';

        // Append the link HTML to the display message
        displayMessage += ` ${link.outerHTML} to add this search.`;
      }

      // Determine the event type based on the availability of profiles
      const event = profileDetails && profileDetails?.length > 0 ? 'change' : 'click';

      // Display the message box with the constructed message
      const messageBox = this.displayMessageBox(displayMessage);

      // Add an event listener to the message box based on the determined event type
      messageBox.querySelector('.stark-add-search').addEventListener(event, e => this.sendPageInfoToBackgroundScript(profileDetails, e, messageBox));
    } else if (window.location.pathname.includes(portal.getListingPath())) {
      chrome.runtime.sendMessage({ action: 'get_stark_access_token' }, response => {
        if (!response.accessToken) {
          const messageBox = this.displayMessageBox(`Stark.ai can fetch the AI match score for this job against your profiles. <br/><strong>Please signup or login to your account.</strong>`);
          messageBox.style.backgroundColor = '#ffcc00';
          messageBox.style.color = '#000000';
        } else {
          portal
            .waitForElement(portal.getDescriptionSelector())
            .then(jobDescriptionElement => {
              const jobDescriptionText = jobDescriptionElement ? jobDescriptionElement.innerText : '';
              portal.getScore({ descriptionText: jobDescriptionText });
            })
            .catch(error => {
              console.error('Error waiting for job description element:', error);
              this.displayMessageBox('Failed to find job description element.');
            });
        }
      });
    } else {
      this.displayMessageBox(`Stark.ai can auto-apply to jobs on this portal. Start searching to see it in action.`);
    }
    JobPortalInterface.checkingPendingJobRun(portal);
  }
  static checkingPendingJobRun(portal) {
    // get_tabId action is called to get current tabId
    chrome.runtime.sendMessage({ action: 'get_tabId' }, async response => {
      const key = `STARK_AUTO_APPLY_${response.tabId}`;
      let t = await chrome.storage.local.get({});
      const { [key]: data } = await chrome.storage.local.get();
      if (!data) return;
      const { job, tabId, profileId } = JSON.parse(data);
      if (response.tabId !== tabId) return;
      portal
        .apply(job, tabId, profileId)
        .then(response => {
          response.url = job.url;
          chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: '' });
          chrome.runtime.sendMessage({ action: 'apply_job_done', url: response.url, message: response, success: true });
        })
        .catch(error => {
          chrome.storage.local.set({ [`STARK_AUTO_APPLY_${tabId}`]: '' });
          chrome.runtime.sendMessage({ action: 'apply_job_done', url: response.url, success: false, message: error.message });
        });
    });
  }

  sendPageInfoToBackgroundScript(profileDetails, event, messageBox) {
    let selectedProfile = '';
    if (event && event.target.tagName === 'SELECT') {
      selectedProfile = profileDetails.find(resume => resume.fileName === event.target.value)?.fileName || '';
    }
    const pageTitle = document.title;
    const pageUrl = window.location.href;
    const favIconUrl = document.querySelector('link[rel="icon"]')?.href;
    const uuid = this.generateUUID();

    chrome.runtime.sendMessage(
      {
        action: 'auto_apply',
        data: {
          title: pageTitle,
          url: pageUrl,
          favIconUrl: favIconUrl,
          uuid: uuid,
          selectedProfile,
        },
      },
      response => {
        if (response) {
          messageBox.remove(); // Close display message box after getting response
          if (response.status === 'success') {
            const successMessage = this.displaySuccessMessage();
            setTimeout(() => successMessage.remove(), 3000); // Close success message box after 3 secs
          } else if (response.status === 'error') {
            const errorMessage = this.displayErrorMessage(response.message);
            setTimeout(() => errorMessage.remove(), 3000); // Close error message box after 3 secs
          }
        }
      }
    );
  }

  generateUUID() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
        (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
  }

  displaySuccessMessage() {
    const successBox = document.createElement('div');
    successBox.style.position = 'fixed';
    successBox.style.top = '20px';
    successBox.style.right = '20px';
    successBox.style.backgroundColor = '#4caf50';
    successBox.style.color = '#ffffff';
    successBox.style.padding = '10px';
    successBox.style.border = '1px solid #4caf50';
    successBox.style.borderRadius = '5px';
    successBox.style.zIndex = '9999';
    successBox.style.display = 'flex';
    successBox.style.alignItems = 'center';
    successBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

    const icon = document.createElement('img');
    icon.src = 'https://v2.stark.ai/static/images/stark-256.png';
    icon.style.width = '32px';
    icon.style.height = '32px';
    icon.style.marginRight = '10px';

    const messageText = document.createElement('span');
    messageText.innerHTML = 'Profile added successfully! You can start your Auto Application Process on Stark.ai.';

    const closeButton = document.createElement('span');
    closeButton.textContent = 'x';
    closeButton.style.marginLeft = '10px';
    closeButton.style.cursor = 'pointer';
    closeButton.addEventListener('click', () => {
      successBox.remove();
    });

    successBox.appendChild(icon);
    successBox.appendChild(messageText);
    successBox.appendChild(closeButton);

    document.body.appendChild(successBox);

    return successBox;
  }

  displayErrorMessage(message) {
    const errorBox = document.createElement('div');
    errorBox.style.position = 'fixed';
    errorBox.style.top = '20px';
    errorBox.style.right = '20px';
    errorBox.style.backgroundColor = '#f44336';
    errorBox.style.color = '#ffffff';
    errorBox.style.padding = '10px';
    errorBox.style.border = '1px solid #f44336';
    errorBox.style.borderRadius = '5px';
    errorBox.style.zIndex = '9999';
    errorBox.style.display = 'flex';
    errorBox.style.alignItems = 'center';
    errorBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

    const icon = document.createElement('img');
    icon.src = 'https://v2.stark.ai/static/images/stark-256.png';
    icon.style.width = '32px';
    icon.style.height = '32px';
    icon.style.marginRight = '10px';

    const messageText = document.createElement('span');
    messageText.innerHTML = message;

    const closeButton = document.createElement('span');
    closeButton.textContent = 'x';
    closeButton.style.marginLeft = '10px';
    closeButton.style.cursor = 'pointer';
    closeButton.addEventListener('click', () => {
      errorBox.remove();
    });

    errorBox.appendChild(icon);
    errorBox.appendChild(messageText);
    errorBox.appendChild(closeButton);

    document.body.appendChild(errorBox);

    return errorBox;
  }

  displayMessageBox(message) {
    const messageBox = document.createElement('div');
    messageBox.className = 'message-box';
    messageBox.style.position = 'fixed';
    messageBox.style.top = '20px';
    messageBox.style.right = '20px';
    messageBox.style.backgroundColor = '#ffffff';
    messageBox.style.color = '#000000';
    messageBox.style.padding = '10px';
    messageBox.style.border = '1px solid #cccccc';
    messageBox.style.borderRadius = '5px';
    messageBox.style.zIndex = '9999';
    messageBox.style.display = 'flex';
    messageBox.style.alignItems = 'center';
    messageBox.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

    const icon = document.createElement('img');
    icon.src = 'https://v2.stark.ai/static/images/stark-256.png';
    icon.style.width = '32px';
    icon.style.height = '32px';
    icon.style.marginRight = '10px';

    const messageText = document.createElement('span');
    messageText.innerHTML = message;

    const closeButton = document.createElement('span');
    closeButton.textContent = 'x';
    closeButton.style.marginLeft = '10px';
    closeButton.style.cursor = 'pointer';
    closeButton.addEventListener('click', () => {
      messageBox.remove();
    });

    messageBox.appendChild(icon);
    messageBox.appendChild(messageText);
    messageBox.appendChild(closeButton);

    document.body.appendChild(messageBox);

    return messageBox;
  }
}
