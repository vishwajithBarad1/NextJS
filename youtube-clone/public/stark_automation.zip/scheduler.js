import { getAccessToken, getUserData, clearAllLocks, clearPortalLock } from './utils.js';
import { JobManager } from './job-manager.js';
import { PORTALS_URL } from './utils.js';

class JobScheduler {
  constructor() {
    this.managers = {}; // To keep track of JobManagers
    this.start();
    console.log("Started job scheduler")
  }

  async start() {
    const token = await getAccessToken();
    const userData = await getUserData(token, true);
    const portals = await this.getPortals(userData?.resumeData);

    // Clear all locks for all portals before starting
    await clearAllLocks(portals.map(({ portalKey }) => portalKey)); //TODO Also clear any pending running locks

    console.log("Portals available to run - ", portals)
    for (const { portalKey, portalData, resume } of portals) {
      const interval = (parseInt(portalData.schedule || 360)) * 60 * 1000; //Schedule given in minutes
      const portalFlow = await this.getPortalFlow(portalKey);
      console.log("Starting Job Manger for portal - ", portalKey, portalData)
      this.startJobManager(portalKey, token, portalData, portalFlow, interval, resume);
    }
  }

  async getPortals(resumeData) {
    const portalMap = new Map();
    try {
      const parsedResumeData = JSON.parse(resumeData);
      parsedResumeData?.forEach(resume => {
        if (Object.keys(resume?.autoApply ?? {})?.length) {
          Object.keys(resume.autoApply).forEach(portalKey => {
            if (!portalMap.has(portalKey)) {
              portalMap.set(portalKey, { portalKey, portalData: resume.autoApply[portalKey], resume });
            }
          });
        }
      });
      return Array.from(portalMap.values());
    } catch (e) {
      return [];
    }
  }

  async getPortalFlow(portal) {
    const response = await fetch(`${PORTALS_URL}/portals/get-auto-apply-json/${portal}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (response.status !== 200) {
      console.error(`Failed to get portal flow for ${portal}`);
      return {}
    }

    return await response.json();
  }

  startJobManager(portal, token, portalData, portalFlow, interval, resume) { //Should call this when new portal is added
    if (this.managers[portal]) {
      this.stopJobManager(portal);
    }
    const jobManager = new JobManager(portal, token, portalData, portalFlow, resume);

    setTimeout(() => this.updateJobs(jobManager, resume), 0)

    this.managers[portal] = {
      manager: jobManager,
      interval: setInterval(() => this.updateJobs(jobManager, resume), interval)
    };
  }

  async updateJobs(jobManager, resume) {
      const job_urls = await jobManager.getJobUrls();
      console.log("Updating Job URLs", job_urls);

      for (let i = 0; i < job_urls.length; i++) {
        await jobManager.updateScheduledJobs([{
          ...job_urls[i],
          resume,
          profile_uuid: resume.uuid,
          type: 'search_jobs',
          priority: -2,
          url: job_urls[i].jobUrl
        }]);
      }
  }

  stopJobManager(portal) { //TODO We should call this when there are no active portals to run 
    if (this.managers[portal]) {
      clearInterval(this.managers[portal].interval);
      delete this.managers[portal];
    }
  }

  updateJobManagerInterval(portal, newInterval) { //TODO just delete the old callback and create new one with updated interval
    if (this.managers[portal]) {
      this.stopJobManager(portal);
      const { token, portalData, portalFlow, resume } = this.managers[portal].manager;
      this.startJobManager(portal, token, portalData, portalFlow, newInterval, resume);
    }
  }

  async getUpdatedPortalData(portal) {
    const token = await getAccessToken();
    const userData = await getUserData(token, true);
    const portals = await this.getPortals(userData?.resumeData);

    for (const { portalKey, portalData, resume } of portals) {
      if (portalKey === portal)
        return {portalData, resume}
    }

    return {}
  }

  async addJobSearch(portal, jobSearchUrl, profile) {
    const portalInfo = await this.getUpdatedPortalData(portal)

    console.log("New Job search added,", portal, jobSearchUrl, portalInfo)

    // If a job manager is already running, update it
    if (this.managers[portal]) {
      const jobManager = this.managers[portal].manager;
      jobManager.updatePortalData(portalInfo.portalData);
    
      // Get the new job search entry
      const job_urls = await jobManager.getJobUrls();
      let new_job_url = null;
      for (let i = 0; i < job_urls.length; i++) {
        if (job_urls[i].jobUrl === jobSearchUrl) {
          new_job_url = job_urls[i]
        }
      }

      if (new_job_url) {
        console.log("New Job URL", new_job_url)
        // Add it in the scheduler job
        await jobManager.updateScheduledJobs([{ 
            ...new_job_url, 
            resume: portalInfo.resume, 
            profile_uuid: portalInfo.resume.uuid, 
            type: 'search_jobs', 
            priority: -2, 
            url: new_job_url.jobUrl 
          }]);
      } else {
        console.log("No new job URL available in resume data")
      }
    
      // If there is only one job URL, clear the existing interval and create a new one with updated settings
      if (job_urls.length === 1) {
        clearInterval(this.managers[portal].interval);
        const interval = (parseInt(portalInfo.portalData.schedule || 360)) * 60 * 1000;
        this.managers[portal].interval = setInterval(() => this.updateJobs(jobManager, portalInfo.resume), interval);
      }

    } else {
      const token = await getAccessToken();
      
      clearPortalLock(portal)
      const portalFlow = await this.getPortalFlow(portal);
      const interval = (parseInt(portalInfo.portalData.schedule || 360)) * 60 * 1000;
      this.startJobManager(portal, token, portalInfo.portalData, portalFlow, interval, portalInfo.resume);
    }
  }
  
  async removeJobSearch(portal, jobSearchUrl, profile) {

     const portalInfo = await this.getUpdatedPortalData(portal)

     console.log("Removing job search URL ", this.managers, this.managers[portal])
    if (this.managers[portal]) {

      const jobManager = this.managers[portal].manager;
      await jobManager.updatePortalData(portalInfo.portalData);

      const deleteJobs = [{ 
        jobUrl: jobSearchUrl,
        searchUrl: jobSearchUrl,
        resume: profile, 
        profile_uuid: profile.uuid, 
        type: 'delete_job', 
        priority: -3, 
        url: jobSearchUrl 
      }];

      console.log("Jobs to be deleted, ", deleteJobs)

      await jobManager.updateScheduledJobs(deleteJobs);
    }
  }

  async deleteJobsForProfile(profileId) {
    for (const portal in this.managers) {
      const jobManager = this.managers[portal].manager;
      await jobManager.createDeleteProfileJob(profileId);
    }

    // Fetch updated user data
    const token = await getAccessToken();
    const userData = await getUserData(token, true);
    const portals = await this.getPortals(userData?.resumeData);

    // Update portal managers with the latest portal data
    for (const { portalKey, portalData, resume } of portals) {
      if (this.managers[portalKey]) {
        const jobManager = this.managers[portalKey].manager;
        jobManager.updatePortalData(portalData);
      }
    }
  }
}

class JobSchedulerSingleton {
  constructor() {
    if (!JobSchedulerSingleton.instance) {
      JobSchedulerSingleton.instance = new JobScheduler();
    }
  }

  getInstance() {
    return JobSchedulerSingleton.instance;
  }
}
let schedulerSingleton = null;

const startJobScheduler = () => {
  if (!schedulerSingleton) {
    schedulerSingleton = new JobSchedulerSingleton();
  }
};

const getJobScheduler = () => {
  // Make sure to have scheduler instance running before returning
  startJobScheduler()
  return schedulerSingleton.getInstance();
};

export { startJobScheduler, getJobScheduler };
