import { PORTALS_URL, getStarkTabs, isYesterdayOrOlder } from './utils.js';
import { SearchJobs } from './search-jobs.js';
import { AutoApply } from './auto-apply.js';

class JobManager {
  constructor(portal, token, applyPrefs, portalFlow, resume) {
    this.portal = portal;
    this.storageKey = `stark-jobs-${portal}`;
    this.lockKey = `lock`;
    this.tab = {};
    this.token = token;
    this.applyPrefs = applyPrefs;
    this.portalFlow = portalFlow;
    this.resume = resume;
    this.jobSearchHelper = null;
    this.autoApplyHelper = null;
    this.maxJobs = applyPrefs.max_jobs || 100;
    this.intervalBetweenJobs = parseInt(applyPrefs.interval_between_jobs || 120) * 1000; // Interval is given in seconds
    this.applyLatestJobs = applyPrefs.apply_latest_jobs || false;
    this.debuggerPortals = ['linkedin', 'indeed', 'freshersworld']
    this.searchJobsStats = {}
    this.lastUpdateTimeStamp = null

    this.initPortalTab();
    this.updateJobsStatus(this.applyPrefs)
    this.runJobs();
  }
  
  async initPortalTab() {
    let tab = await this._getTab();
    if (!tab) {
      tab = await this._openNewTab();
      if (this.debuggerPortals.includes(this.portal))
        await chrome.debugger.attach({ tabId: tab.id }, '1.3');
    }
    this.tab = tab;

    this.jobSearchHelper = new SearchJobs(this.portal, this.token, this.tab, {applyLatestJobs: this.applyLatestJobs});
    this.autoApplyHelper = new AutoApply(this.portal, this.token, this.tab);
  }

  async _getTab(tabKey = 'tabId') {
    const tabId = await this.getLocalStorage(tabKey);
    if (tabId) {
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab && tab.status !== 'closed') {
          return tab;
        }
      } catch (error) {
        console.warn(`Tab with ID ${tabId} is not open`);
      }
    }
    return null;
  }

  async _openNewTab(tabKey = 'tabId') {
    return new Promise(resolve => {
      chrome.tabs.create({ url: this.portal, active: false }, tab => {
        this.setLocalStorage(tabKey, tab.id);
        resolve(tab);
      });
    });
  }

  async getJobUrls() {
    return this.applyPrefs?.job_urls || [];
  }

  async updatePortalData(portalData) {
    this.applyPrefs = portalData;
    this.maxJobs = this.applyPrefs?.max_jobs || 100;
    this.intervalBetweenJobs = parseInt(this.applyPrefs?.interval_between_jobs || 120) * 1000; // Interval is given in seconds
    this.applyLatestJobs = this.applyPrefs?.apply_latest_jobs || false; 

    this.updateJobsStatus(portalData)
  }

  updateJobsStatus(portalData) {
    // Iterate through the job_urls array
    portalData?.job_urls?.forEach(jobSearchUrl => {
        const key = this.getJobCountKeyString(this.portal, jobSearchUrl.profile_uuid, jobSearchUrl.jobUrl);
        if (!this.searchJobsStats[key]) {
            this.searchJobsStats[key] = {
            maxJobs: jobSearchUrl.jobsToApply
         };
        } else {
            this.searchJobsStats[key].maxJobs = jobSearchUrl.jobsToApply  
        }
    });

    console.log("Jobs Status Keys", this.searchJobsStats)
  }

  getMaxJobsForJobSearch(jobSearchUrl) {
    if (!this.portalData || !this.portalData.job_urls || !Array.isArray(this.portalData.job_urls)) {
      return 0;
    }

    const matchingJobUrl = this.portalData.job_urls.find(job => job.jobUrl === jobSearchUrl);

    return matchingJobUrl ? matchingJobUrl.jobsToApply : 0;
  }

  async checkTabClosure() {
    // Check if tab still exists, if not create one and update
    const currentTab = await this._getTab()
    if (!currentTab) {
        console.log("Old tab is closed, creating new tab")
        await this.initPortalTab()
    }
  }

  async runJobs() {
    while (true) {

      if (await this.acquireLock()) {
        try {
          await this.clearStaleJob();
          let scheduledJobs = await this.getScheduledJobs();

          while (scheduledJobs.length > 0 && !(await this.isJobRunning())) {
            await this.checkTabClosure();

            let execStatus = {}
            const nextJob = await this.getNextJobFromScheduler();
            scheduledJobs = scheduledJobs.filter(item => item.url !== nextJob.url);
            await this.setLocalStorage('scheduled-jobs', scheduledJobs);
            
            execStatus = await this.exec(nextJob);

            await this.sleep(this.intervalBetweenJobs);
            scheduledJobs = await this.getScheduledJobs();
          }

        } finally {
          await this.releaseLock();
        }
      }
      await this.sleep(this.intervalBetweenJobs);
    }
  }

  async exec(job) {
    if (await this.isJobRunning()) {
      throw new Error('A job is already running');
    }

    await this.lockJob();
    // await this.updateStatus(job, 'running');

    let autoApplyStatus = {}

    try {
      await this.setLocalStorage('running-job', { job: job, portal: this.portal, start_time: Date.now() });

      console.log("Running job - ", this.portal, job)

      // Check if debugger is still active for the required portals every time a job is run
      if (this.debuggerPortals.includes(this.portal) && !await this.checkDebugger()) {
        await chrome.debugger.attach({ tabId: this.tab.id }, '1.3');
      }

      switch (job.type) {
        case 'search_jobs':
          const searchedJobs = await this.jobSearchHelper?.exec_search_jobs(job);
          await this.updateScheduledJobs(searchedJobs);
          break;
        case 'auto_apply':
          // Check if max job apply count reached
          if (!await this.checkIfApplyLimitExceeded(job)) {
              autoApplyStatus = await this.autoApplyHelper?.exec_apply_job(job, this.portalFlow);
          } else {
              autoApplyStatus = { status: 'skipped', reason: 'Apply limit exceeded' };
              // Push the skipped job back into the scheduledJobs list
              const scheduledJobs = await this.getScheduledJobs();
              scheduledJobs.push(job);
              await this.setLocalStorage('scheduled-jobs', scheduledJobs);
          }
          break;
        case 'delete_job':
          await this.deleteJobs(job)
          break;
        case "delete_profile":
          await this.deleteJobsForProfile(job.profile_uuid);
          break;
        default:
          autoApplyStatus = await this.autoApplyHelper.exec_apply_job(job, this.portalFlow);
      }

      await this.updateStatus(job, autoApplyStatus?.status , autoApplyStatus?.reason)
      await this.unlockJob();
    } catch (error) {
      await this.updateStatus(job, 'error', null, error.message || error.error);
      await this.unlockJob();
      //throw error;
    }

    return autoApplyStatus;
  }

  async acquireLock() {
    const lock = await this.getLocalStorage(this.lockKey);
    const currentTime = Date.now();

    if (!lock || currentTime - lock.timestamp > this.intervalBetweenJobs) {
      await this.setLocalStorage(this.lockKey, { timestamp: currentTime });
      return true;
    }
    return false;
  }

  async releaseLock() {
    await this.setLocalStorage(this.lockKey, null);
  }

  closeTab(tabId = this.tab.id) {
    if (this.debuggerPortals.includes(this.portal))
        chrome.debugger.detach({ tabId });
    return new Promise(resolve => {
      try {
        chrome.tabs.remove(tabId, () => {
          if (chrome.runtime.lastError) {
            resolve(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      } catch (e) {
        resolve('closed');
      }
    });
  }

  // Check if job apply limit exceeded for the day
  async checkIfApplyLimitExceeded(job) {
    const jobKey = this.getJobCountKey(job);
    const lastUpdatedTime = this.searchJobsStats[jobKey]?.lastUpdateTimestamp;

    console.log("Check if Apply limit exceeded,", job, jobKey, lastUpdatedTime);
    console.log("Jobs Status Keys", this.searchJobsStats)

    // Fetch the overall portal-profile applied jobs count from the server
    const portalProfilePayload = {
      portal: this.portal,
      profile: job.profile_uuid,
      search_url: '', // Set search_url to an empty string for overall count
    };

    const portalProfileFetchResponse = await fetch(`${PORTALS_URL}/jobs/applied-jobs-count`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(portalProfilePayload),
    });

    const portalProfileResult = await portalProfileFetchResponse.json();

    if (portalProfileFetchResponse.ok) {
      const overallAppliedJobsCount = portalProfileResult.appliedCount;

      // Check if the overall applied jobs count exceeds the portal limit
      if (overallAppliedJobsCount >= this.maxJobs) {
        console.log("Overall portal limit exceeded");
        return true;
      }
    } else {
      console.error("Failed to fetch overall applied jobs count from server:", portalProfileResult);
      return false;
    }

    // If no last updated time present, or if its on previous day, fetch the applied jobs count from the server
    if (!lastUpdatedTime || isYesterdayOrOlder(lastUpdatedTime)) {
      console.log("Timestamp not present or last date", lastUpdatedTime);

      // Fetch the applied jobs count for the specific jobSearchUrl from the server
      const jobSearchUrlPayload = {
        portal: this.portal,
        profile: job.profile_uuid,
        search_url: job?.searchUrl,
      };

      const jobSearchUrlFetchResponse = await fetch(`${PORTALS_URL}/jobs/applied-jobs-count`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(jobSearchUrlPayload),
      });

      const jobSearchUrlResult = await jobSearchUrlFetchResponse.json();

      if (jobSearchUrlFetchResponse.ok) {
        const jobSearchUrlAppliedJobsCount = jobSearchUrlResult.appliedCount;

        // Update the searchJobsStats object with the fetched applied jobs count and current timestamp
        if (!this.searchJobsStats[jobKey]) {
          this.searchJobsStats[jobKey] = {
            maxJobs: this.getMaxJobsForJobSearch(job.jobSearchUrl),
            appliedJobs: jobSearchUrlAppliedJobsCount,
            lastUpdateTimestamp: Date.now(),
          };
        } else {
          this.searchJobsStats[jobKey].appliedJobs = jobSearchUrlAppliedJobsCount;
          this.searchJobsStats[jobKey].lastUpdateTimestamp = Date.now();
        }

        console.log("Applied jobs count fetched from server for jobSearchUrl:", jobSearchUrlAppliedJobsCount);

        // Check if the applied jobs count for the jobSearchUrl exceeds its limit
        return jobSearchUrlAppliedJobsCount >= this.searchJobsStats[jobKey].maxJobs;
      } else {
        console.error("Failed to fetch applied jobs count from server for jobSearchUrl:", jobSearchUrlResult);
        return false;
      }
    } else {
      console.log("Checking the job count - ", this.searchJobsStats[jobKey]);

      // Check if the applied jobs count for the jobSearchUrl exceeds its limit
      return this.searchJobsStats[jobKey].appliedJobs >= this.searchJobsStats[jobKey].maxJobs;
    }
  }

  async isJobRunning() {
    const runningJob = await this.getLocalStorage('running-job');
    return !!runningJob;
  }

  async isStale() {
    const runningJob = await this.getLocalStorage('running-job');
    if (runningJob) {
      const currentTime = Date.now();
      return currentTime - runningJob.start_time > 120000;
    }
    return false;
  }

  async clearStaleJob() {
    const isStale = await this.isStale();
    if (isStale) {
      await this.updateStatus(await this.getLocalStorage('running-job'), 'stale');
      await this.unlockJob();
      console.warn(`Cleared stale job for portal: ${this.portal}`);
    }
  }

  async getHistory() {
    const response = await fetch(`http://127.0.0.1:8000/jobs/history/${this.portal}`);
    return await response.json();
  }

  async getScheduledJobs() {
    const scheduledJobs = (await this.getLocalStorage('scheduled-jobs')) || [];
    return scheduledJobs;
  }

  async updateScheduledJobs(jobs) {
    console.log("Updating scheduled jobs", jobs)
    const scheduledJobs = (await this.getLocalStorage('scheduled-jobs')) || [];
    
    const existingJobIdentifiers = new Set(scheduledJobs.map(job => `${job.url}_${job.type}`));

    // Check for duplicate jobs in the scheduler - matching both URL and type
    const newJobs = jobs.filter(job => !existingJobIdentifiers.has(`${job.url}_${job.type}`));

    if (newJobs.length > 0) {
        console.log("New jobs being added to the scheduled jobs", this.portal, newJobs)
        await this.setLocalStorage('scheduled-jobs', [...scheduledJobs, ...newJobs]);
    }
    
    return scheduledJobs;
  }

  async deleteJobs(job) {
    // Delete the job key related to the JobURL from local storage
    const jobKey = `job-listing-${this.portal}-${job.profile_uuid}-${job.url}`;
  
    console.log("Removing job key -", jobKey)
    // Remove the jobKey from Chrome local storage
    await new Promise((resolve, reject) => {
        chrome.storage.local.remove(jobKey, () => {
        if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
        } else {
            resolve();
        }
        });
    });

    // Delete all the jobs in the scheduler whose jobSearchURL is matching the current URL
    const scheduledJobs = (await this.getLocalStorage('scheduled-jobs')) || [];
    const updatedJobs = scheduledJobs.filter(jobItem => jobItem.searchUrl !== job.url && jobItem.url !== job.url);

    console.log("Updated Jobs -", updatedJobs)
    await this.setLocalStorage('scheduled-jobs', updatedJobs);
  }

  async getNextJobFromScheduler() {
    const scheduledJobs = (await this.getLocalStorage('scheduled-jobs')) || [];
    scheduledJobs.sort((a, b) => a.priority - b.priority);
    return scheduledJobs[0];
  }

  async lockJob() {
    await this.setLocalStorage('lock', true);
  }

  async unlockJob() {
    await this.setLocalStorage('lock', false);
    await this.setLocalStorage('running-job', null);
  }

  async getLocalStorage(key) {
    const storageKey = `${this.storageKey}-${key}`;
    const result = await new Promise(resolve => {
      chrome.storage.local.get(storageKey, items => {
        resolve(items[storageKey]);
      });
    });
    return result;
  }

  async setLocalStorage(key, value) {
    const storageKey = `${this.storageKey}-${key}`;
    await new Promise(resolve => {
      chrome.storage.local.set({ [storageKey]: value }, () => {
        resolve();
      });
    });
  }

  async updateStatus(job, status, failureReason = null, errorMessage = null) {

    // No need to update the non auto apply job status to portal
    if(job.type !== 'auto_apply')
        return
    
    const updateTimestamp = Date.now()

    const payload = {
      portal: this.portal,
      job: job,
      status: status,
      reason: failureReason,
      errorMessage: errorMessage,
      timestamp: updateTimestamp,
    };

    const fetchResponse = await fetch(`${PORTALS_URL}/jobs/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const result = await fetchResponse.json();

    console.log("Update status result - ", result)

    if (fetchResponse.ok && result.status === 'success') {
        const jobKey = this.getJobCountKey(job)
        // Assuming you have a jobs object to store the jobKey data
        if (result.appliedCount && this.searchJobsStats[jobKey]) {
            this.searchJobsStats[jobKey].appliedJobs = result.appliedCount
            this.searchJobsStats[jobKey].lastUpdateTimestamp = updateTimestamp
        }

        console.log("Applied count updated", jobKey, result.appliedCount, this.searchJobsStats[jobKey])

        console.log("Job status updated successfully:", result);
    } else {
        console.error("Job status update failed:", result);
    }

    // Get stark tab details
    const starkTabs = await getStarkTabs()
    if(!starkTabs || !starkTabs?.length) return

    // Send message to stark tab to update job status in UI
    // starkTabs.forEach(tab => chrome.tabs.sendMessage(tab.id, { action: "update_job_status", status, url: job.url, errorMessage, reason: failureReason }));
  }

  getJobCountKey(job) {
    return `job-count-${this.portal}-${job.profile_uuid}-${job.searchUrl}`;
  }

  getJobCountKeyString(portal, profileId, searchUrl) {
    return `job-count-${portal}-${profileId}-${searchUrl}`;
  }

  async checkDebugger(tabId = this.tab.id) {
    return new Promise((resolve) => {
      chrome.debugger.getTargets(targets => {
        const target = targets.find(target => target.tabId === tabId);
        resolve(target && target.attached);
      });
    });
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Delete profile job 
  async createDeleteProfileJob(profileId) {
    const deleteProfileJob = {
      type: "delete_profile",
      profile_uuid: profileId,
      priority: -5,
      url: `delete_profile_${profileId}`,
      searchUrl: `delete_profile_${profileId}`
    };

    const scheduledJobs = await this.getScheduledJobs();
    scheduledJobs.push(deleteProfileJob);
    await this.setLocalStorage("scheduled-jobs", scheduledJobs);
  }

  async deleteJobsForProfile(profileId) {
    const scheduledJobs = await this.getScheduledJobs();
    const updatedJobs = scheduledJobs.filter((job) => job.profile_uuid !== profileId);

    // Delete job keys related to the profile ID from local storage
    const jobKeys = await new Promise((resolve) => {
      chrome.storage.local.get(null, (items) => {
        const keys = Object.keys(items).filter((key) =>
          key.startsWith(`job-listing-${this.portal}-${profileId}-`)
        );
        resolve(keys);
      });
    });

    await new Promise((resolve, reject) => {
      chrome.storage.local.remove(jobKeys, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });

    await this.setLocalStorage("scheduled-jobs", updatedJobs);
  }
}

export { JobManager };
